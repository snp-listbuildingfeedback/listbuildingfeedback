<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Zero
 * Date: 3/12/13
 * Time: 10:30 AM
 * To change this template use File | Settings | File Templates.
 */
?>
<!-- AWeber Web Form Generator 3.0 -->
<style type="text/css">
    #af-form-543446586 .af-body .af-textWrap{width:98%;display:block;float:none;}
    #af-form-543446586 .af-body input.text, #af-form-543446586 .af-body textarea{background-color:#FFFFFF;border-color:#919191;border-width:1px;border-style:solid;color:#000000;text-decoration:none;font-style:normal;font-weight:normal;font-size:12px;font-family:Verdana, sans-serif;}
    #af-form-543446586 .af-body input.text:focus, #af-form-543446586 .af-body textarea:focus{background-color:#FFFAD6;border-color:#030303;border-width:1px;border-style:solid;}
    #af-form-543446586 .af-body label.previewLabel{display:block;float:none;text-align:left;width:auto;color:#000000;text-decoration:none;font-style:normal;font-weight:normal;font-size:12px;font-family:Verdana, sans-serif;}
    #af-form-543446586 .af-body{padding-bottom:15px;padding-top:15px;background-repeat:no-repeat;background-position:inherit;background-image:none;color:#000000;font-size:11px;font-family:Verdana, sans-serif;}
    #af-form-543446586 .af-quirksMode{padding-right:15px;padding-left:15px;}
    #af-form-543446586 .af-standards .af-element{padding-right:15px;padding-left:15px;}
    #af-form-543446586 .buttonContainer input.submit{background-image:url("http://forms.aweber.com/images/auto/gradient/button/07c.png");background-position:top left;background-repeat:repeat-x;background-color:#0057ac;border:1px solid #0057ac;color:#FFFFFF;text-decoration:none;font-style:normal;font-weight:normal;font-size:14px;font-family:Verdana, sans-serif;}
    #af-form-543446586 .buttonContainer input.submit{width:auto;}
    #af-form-543446586 .buttonContainer{text-align:right;}
    #af-form-543446586 button,#af-form-543446586 input,#af-form-543446586 submit,#af-form-543446586 textarea,#af-form-543446586 select,#af-form-543446586 label,#af-form-543446586 optgroup,#af-form-543446586 option{float:none;position:static;margin:0;}
    #af-form-543446586 div{margin:0;}
    #af-form-543446586 form,#af-form-543446586 textarea,.af-form-wrapper,.af-form-close-button,#af-form-543446586 img{float:none;color:inherit;position:static;background-color:none;border:none;margin:0;padding:0;}
    #af-form-543446586 input,#af-form-543446586 button,#af-form-543446586 textarea,#af-form-543446586 select{font-size:100%;}
    #af-form-543446586 select,#af-form-543446586 label,#af-form-543446586 optgroup,#af-form-543446586 option{padding:0;}
    #af-form-543446586,#af-form-543446586 .quirksMode{width:225px;}
    #af-form-543446586.af-quirksMode{overflow-x:hidden;}
    #af-form-543446586{background-color:#F0F0F0;border-color:#CFCFCF;border-width:1px;border-style:solid;}
    #af-form-543446586{display:block;}
    #af-form-543446586{overflow:hidden;}
    .af-body .af-textWrap{text-align:left;}
    .af-body input.image{border:none!important;}
    .af-body input.submit,.af-body input.image,.af-form .af-element input.button{float:none!important;}
    .af-body input.text{width:100%;float:none;padding:2px!important;}
    .af-body.af-standards input.submit{padding:4px 12px;}
    .af-clear{clear:both;}
    .af-element label{text-align:left;display:block;float:left;}
    .af-element{padding:5px 0;}
    .af-form-wrapper{text-indent:0;}
    .af-form{text-align:left;margin:auto;}
    .af-quirksMode .af-element{padding-left:0!important;padding-right:0!important;}
    .lbl-right .af-element label{text-align:right;}
    body {
    }
</style>
<form method="post" class="af-form-wrapper" action="http://www.aweber.com/scripts/addlead.pl"  >
    <div style="display: none;">
        <input type="hidden" name="meta_web_form_id" value="543446586" />
        <input type="hidden" name="meta_split_id" value="" />
        <input type="hidden" name="listname" value="20freereportskf" />
        <input type="hidden" name="redirect" value="http://365plr.com/oto" id="redirect_f1430275e9bd77cf1aaa6af1bc39f2f0" />
        <input type="hidden" name="meta_redirect_onlist" value="http://365plr.com/oto" />
        <input type="hidden" name="meta_adtracking" value="My_Web_Form" />
        <input type="hidden" name="meta_message" value="1" />
        <input type="hidden" name="meta_required" value="name,email" />

        <input type="hidden" name="meta_tooltip" value="" />
    </div>
    <div id="af-form-543446586" class="af-form"><div id="af-body-543446586"  class="af-body af-standards">
        <div class="af-element">
            <label class="previewLabel" for="awf_field-42217676">Name: </label>
            <div class="af-textWrap">
                <input id="awf_field-42217676" type="text" name="name" class="text" value=""  tabindex="500" />
            </div>
            <div class="af-clear"></div></div>
        <div class="af-element">
            <label class="previewLabel" for="awf_field-42217677">Email: </label>
            <div class="af-textWrap"><input class="text" id="awf_field-42217677" type="text" name="email" value="" tabindex="501"  />
            </div><div class="af-clear"></div>
        </div>
        <div class="af-element buttonContainer">
            <input name="submit" class="submit" type="submit" value="Submit" tabindex="502" />
            <div class="af-clear"></div>
        </div>
    </div>
    </div>
    <div style="display: none;"><img src="http://forms.aweber.com/form/displays.htm?id=rCzMLCxsrBxs" alt="" /></div>
</form>
<script type="text/javascript">
    <!--
    (function() {
        var IE = /*@cc_on!@*/false;
        if (!IE) { return; }
        if (document.compatMode && document.compatMode == 'BackCompat') {
            if (document.getElementById("af-form-543446586")) {
                document.getElementById("af-form-543446586").className = 'af-form af-quirksMode';
            }
            if (document.getElementById("af-body-543446586")) {
                document.getElementById("af-body-543446586").className = "af-body inline af-quirksMode";
            }
            if (document.getElementById("af-header-543446586")) {
                document.getElementById("af-header-543446586").className = "af-header af-quirksMode";
            }
            if (document.getElementById("af-footer-543446586")) {
                document.getElementById("af-footer-543446586").className = "af-footer af-quirksMode";
            }
        }
    })();
    -->
</script>

<!-- /AWeber Web Form Generator 3.0 -->
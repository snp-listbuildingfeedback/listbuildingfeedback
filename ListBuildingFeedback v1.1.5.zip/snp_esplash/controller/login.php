<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Zero
 * Date: 3/1/13
 * Time: 4:05 PM
 * To change this template use File | Settings | File Templates.
 */

class Login extends CoreLoader{
    private $_hash;

    public function __construct(){
        parent::__construct();
    }

    public function index(){
        $this->_hash = new classVigenere();
        if($_POST){
            $row = $this->QuerySingleRow("SELECT * FROM ".USERTABLE." where username ='".$_POST['username']."'");
            if($row){
                $raw = $_POST['password'].$row->salt;
                if($raw==$this->_hash->decrypt($row->password)){
                    $this->set_session('user',array('username'=>$row->username,'uid'=>$row->id));
                    $this->redirect('Dashboard');
                }else{
                    self::set_flasher("Username or password did not match.");
                }
            }
        }
        $this->_data['title']="Login";
        $this->_data["content"] = self::view('partial/login');
        print $this->view('template',$this->_data);
    }

    public function logout(){
        $this->kill_session("",true);
        $this->redirect('Login');
    }
}

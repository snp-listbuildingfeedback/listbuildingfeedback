<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Zero
 * Date: 3/1/13
 * Time: 4:05 PM
 * To change this template use File | Settings | File Templates.
 */

class Dashboard extends CoreLoader{

    function __construct(){
        parent::__construct();
        if(!is_user_logged_in()){
            echo '<h1>You do not have access to this page</h1>';
            die();
        }


        $this->_data['_styles']='<link rel="stylesheet" href="'.BASEURL.'/resources/component/colorpicker/css/colorpicker.css" type="text/css" />';
        $this->_data['_scripts']='<script type="text/javascript" src="'.BASEURL.'/resources/component/colorpicker/js/colorpicker.js"></script>';

        $user = $this->get_session('user');
        $this->_data['title']="Dashboard";
        $this->_data['user']=$user['username'];
        $this->_data['actives']=(isset($_GET["m"])) ? strtolower($_GET["m"]) : "index";
    }

    public function index(){
        $this->_data['splashlist'] = $this->get(ESPLASHTABLE);
        $this->_data['content']=$this->view('partial/list',$this->_data);
        print $this->view('template',$this->_data);
    }

    public function deletelist(){
        if($_POST){
            $del = $_POST['echeck'];
            $idsToDelete = implode($del, ', ');
            $this->Query("DELETE FROM wpeerexitsplash WHERE id in ($idsToDelete)");
            $this->redirect('dashboard','index');
        }
    }

    public function profile(){
        if(isset($_GET['eid']))
        {
            $this->SelectRows(ESPLASHTABLE,array('id'=>$_GET['eid']));
            if($this->RowCount()){
                $this->_data['encryptor'] = new classVigenere();
                $this->_data['includescript'] = true;
                $this->_formdata =  $this->set_formdata($this->Row());
                $this->_data['content']=$this->view('partial/dashboard',$this->_data);
                print $this->view('template',$this->_data);
            }else{
                $this->redirect('dashboard','index');
            }
        }else{
            $this->redirect('dashboard','index');
        }
    }

    public function addesplash(){
        if($_POST){
            $form_validation = new Form_Validation();
            $html_error = $form_validation->Run('splashsettings');
            if(!$html_error){
                $sql= $this->buildSqlQuery();

                if($this->Query($sql)){
                    $this->set_flasher('New entry has been successfully added.',true);
                    $this->redirect('dashboard');
                }
                print_r($this->Error());
            }else{
                $this->set_flasher($form_validation->get_error_result());
            }
        }
        $this->_data['content']=$this->view('partial/dashboard',$this->_data);
        print $this->view('template',$this->_data);
    }

    public function update(){
        if($_POST){
            $form_validation = new Form_Validation();
            $html_error = $form_validation->Run('splashsettings');
            if(!$html_error){
                $sql= $this->buildSqlQuery(ProcessEnum::Update);

                if($this->UpdateRows(ESPLASHTABLE,$sql,array('id'=>$this->_formdata['eid']))){
                    $this->set_flasher('New entry has been successfully updated.',true);
                    $this->redirect('dashboard');
                }
                print_r($this->Error());
            }else{
                $this->set_flasher($form_validation->get_error_result());
            }
        }
        $this->_data['content']=$this->view('partial/dashboard',$this->_data);
        print $this->view('template',$this->_data);
    }

    public function formgenerator(){
        $this->_data['_scripts'].='<script type="text/javascript" src="'.BASEURL.'/resources/component/zeroclipboard/ZeroClipboard.js"></script>';
        if($_POST){
            $buttondeefault = '<a href="#" class="uibutton" id="wpeer-button-aweber" >Send</a>';
            $buttonimage = '<a href="#" class="wpeer-ui-button-image" id="wpeer-button-aweber"  ><img src="'. $_POST['button_image_url'] .'" alt="" ></a>';

            $posturl = (trim($_POST['meta_form_post_url']) == "") ? 'http://www.aweber.com/scripts/addlead.pl' : $_POST['meta_form_post_url'];
            $webformid = (trim($_POST['meta_web_form_id']) == "") ? 0 : $_POST['meta_web_form_id'];
            $arscript = '';
            if(strpos($posturl,'getresponse') !== false){
                $arscript = '<script type="text/javascript" src="http://app.getresponse.com/view_webform.js?wid='.$webformid.'&mg_param1=1"></script>';
            }

            $button = (isset($_POST['use_image_for_button'])) ? $buttonimage : $buttondeefault;
            $html = file_get_contents(VIEWPATH.'/partial/aform.html');
            $pattern = array('{META_WEB_FORM_ID_VALUE}','{LISTNAME_VALUE}','{REDIRECT_VALUE}','{META_REDIRECT_ONLIST_VALUE}','{META_ADTRACKING_VALUE}','{META_REQUIRED_VALUE}','{DISPLAY_REQUIRED}','{DISPLAY_CLASS}','{WPEER_BUTTON_IMAGE}','{META_FORM_POST_URL}','{GETRESPONSESCRIPT}');
            $callback = array($webformid,$_POST['listname'],$_POST['redirect'],$_POST['meta_redirect_onlist'],$_POST['meta_adtracking'],$_POST['meta_required'], ($_POST['meta_required'] == 'email') ? "none":"block",($_POST['meta_required'] == 'email') ? "widthsize":"threecolums",$button,$posturl,$arscript);
            $html = preg_replace($pattern,$callback,$html);

            $this->set_flasher("<div class='aformgenwrap'><a href='#' >Close</a><textarea id='aformgentxt' class='aformgentxt'>".htmlentities($html)."</textarea><a id='copyclipboard' class='copyclipboard' href='#' >Copy to clipboard</a></div>");
        }
        $this->_data['content']=$this->view('partial/aformgen',$this->_data);
        print $this->view('template',$this->_data);
    }

    public function report(){
        $this->_data['reportlist'] = $this->getquery("SELECT exiturl,description,customdescription, COUNT(*) AS total FROM ".LEAVEOPTIONTABLE."  GROUP BY exiturl,description");
        $this->_data['content']=$this->view('partial/report',$this->_data);
        print $this->view('template',$this->_data);
    }

    private function buildSqlQuery($type = ProcessEnum::Insert){
        switch($type){
            case ProcessEnum::Insert:
                $data ="'". $this->_formdata['allowcustomreason'] ."',";
                $data.="'". $this->_formdata['exiturl'] ."',";
                $data.="'". $this->_formdata['exitsplashpage'] ."',";
                $data.="'". $this->_formdata['feedbackbutton'] ."',";
                $data.="'". $this->_formdata['isfeedbackbuttonimage'] ."',";
                $data.="'". $this->_formdata['feedbackbuttonimageurl'] ."',";
                $data.="'". $this->_formdata['poweredby'] ."',";
                $data.="'". $this->_formdata['poweredbylink'] ."',";
				$data.="'". $this->_formdata['poweredbycolor'] ."',";
                $data.="'". $this->_formdata['eottitle'] ."',";
                $data.="'". $this->_formdata['optionlabela']."|". $this->_formdata['optionlabela']."',";
                $data.="'". $this->_formdata['optionlabelb']."|". $this->_formdata['optionlabelb']."',";
                $data.="'". $this->_formdata['optionlabelc']."|". $this->_formdata['optionlabelc']."',";
                $data.="'". $this->_formdata['optionlabeld']."|". $this->_formdata['optionlabeld']."',";
                $data.="'". $this->buildstyles(ElementStyleEnum::Option) ."',";
                $data.="'". $this->buildstyles(ElementStyleEnum::Box) ."',";
                $data.="'". $this->buildstyles(ElementStyleEnum::Header) ."',";
                $data.="'". $this->_formdata['alertmessage'] ."',";
                $data.="". 5 .",";//$this->_formdata['breakevery']
                $data.="". ((trim($this->_formdata['emailvaluelabel'])!= "") ? 1 : 0) .",";
                $data.="'". $this->_formdata['awebera'] ."',";
                $data.="'". $this->_formdata['aweberb'] ."',";
                $data.="'". $this->_formdata['aweberc'] ."',";
                $data.="'". $this->_formdata['aweberd'] ."',";
                $data.="'". $this->_formdata['awebercustom'] ."',";
                $data.="'". $this->_formdata['emailvaluelabel'] ."',";
                $data.="'". date('Y-m-d H:i:s') ."'";
                $sql="INSERT INTO `wpeerexitsplash` VALUES (default ,$data)";

                return $sql;
            break;
            case ProcessEnum::Update:
                $data = array(
                    'allowcustomreason'=>"'".$this->_formdata['allowcustomreason']."'",
                    'exiturl'=>"'".$this->_formdata['exiturl']."'",
                    'exitsplashpage'=>"'".$this->_formdata['exitsplashpage']."'",
                    'feedbackbutton'=>"'".$this->_formdata['feedbackbutton']."'",
                    'isfeedbackbuttonimage'=>"'".$this->_formdata['isfeedbackbuttonimage']."'",
                    'feedbackbuttonimageurl'=>"'".$this->_formdata['feedbackbuttonimageurl']."'",
                    'poweredby'=>"'".$this->_formdata['poweredby']."'",
                    'poweredbylink'=>"'".$this->_formdata['poweredbylink']."'",
					'poweredbycolor'=>"'".$this->_formdata['poweredbycolor']."'",
                    'eottitle'=>"'".$this->_formdata['eottitle']."'",
                    'optionlabela'=>"'".$this->_formdata['optionlabela']."|".$this->_formdata['optionlabela']."'",
                    'optionlabelb'=>"'".$this->_formdata['optionlabelb']."|".$this->_formdata['optionlabelb']."'",
                    'optionlabelc'=>"'".$this->_formdata['optionlabelc']."|".$this->_formdata['optionlabelc']."'",
                    'optionlabeld'=>"'".$this->_formdata['optionlabeld']."|".$this->_formdata['optionlabeld']."'",
                    'optionlabelstyle'=>"'".$this->buildstyles(ElementStyleEnum::Option)."'",
                    'eotmaindivstyles'=>"'".$this->buildstyles(ElementStyleEnum::Box)."'",
                    'eotheaderstyles'=>"'".$this->buildstyles(ElementStyleEnum::Header)."'",
                    'alerttext'=>"'".$this->_formdata['alertmessage']."'",
                    'breakevery'=>5,//$this->_formdata['breakevery'],
                    'isemailoption'=>((trim($this->_formdata['emailvaluelabel'])!= "") ? 1 : 0),
                    'awebera'=>"'". AntiXSS::setEncoding($this->_formdata['awebera'],'utf-8')."'",
                    'aweberb'=>"'". AntiXSS::setEncoding($this->_formdata['aweberb'],'utf-8')."'",
                    'aweberc'=>"'". AntiXSS::setEncoding($this->_formdata['aweberc'],'utf-8')."'",
                    'aweberd'=>"'". AntiXSS::setEncoding($this->_formdata['aweberd'],'utf-8')."'",
                    'awebercustom'=>"'". AntiXSS::setEncoding($this->_formdata['awebercustom'],'utf-8')."'",
                    'emailvaluelabel'=>"'". AntiXSS::setEncoding($this->_formdata['emailvaluelabel'],'utf-8')."'"

                );
                return $data;
                break;
        }

    }

    private function buildstyles($type){
        $sql='';
        switch($type){
            case ElementStyleEnum::Option:
                $sql .='font-family:'.$this->ifloadDefaults(ElementStyleTypeEnum::Font,$this->_formdata['label_font-family']).';';
                $sql .='font-size:'.$this->ifloadDefaults(ElementStyleTypeEnum::FontSize,$this->_formdata['label_font-size']).';';
                $sql .='color:'.$this->ifloadDefaults(ElementStyleTypeEnum::FontColor,$this->_formdata['label_font-color']).';';
                break;
            case ElementStyleEnum::Box:
                $sql .='width:'.$this->ifloadDefaults(ElementStyleTypeEnum::widthSize,$this->_formdata['eotbox_width']).';';
                $sql .='height:'.$this->ifloadDefaults(ElementStyleTypeEnum::heightSize,$this->_formdata['eotbox_height']).';';
                $sql .='margin-top:'.$this->ifloadDefaults(ElementStyleTypeEnum::marginSize,$this->_formdata['eotbox_margin-top']).';';
                $sql .='background-color:'.$this->ifloadDefaults(ElementStyleTypeEnum::FontColor,$this->_formdata['eotbox_background-color']).';';
                $sql .='border-width:'.$this->ifloadDefaults(ElementStyleTypeEnum::borderSize,$this->_formdata['eotbox_border']).';';
                $sql .='border-color:'.$this->ifloadDefaults(ElementStyleTypeEnum::FontColor,$this->_formdata['eotbox_border-color']).';';
                break;
            case ElementStyleEnum::Header:
                $sql .='font-family:'.$this->ifloadDefaults(ElementStyleTypeEnum::Font,$this->_formdata['eotheader_font-family']).';';
                $sql .='font-size:'.$this->ifloadDefaults(ElementStyleTypeEnum::FontSize,$this->_formdata['eotheader_font-size']).';';
                $sql .='color:'.$this->ifloadDefaults(ElementStyleTypeEnum::FontColor,$this->_formdata['eotheader_color']).';';
                $sql .='background-color:'.$this->ifloadDefaults(ElementStyleTypeEnum::FontColor,$this->_formdata['eotheader_background-color']).';';
                break;
        }

        return $sql;
    }

    private function ifloadDefaults($type,$ele){
        switch($type){
            case ElementStyleTypeEnum::Font:
                if(trim($ele) == ""){
                    return 'Tahoma';
                }else{
                    return htmlentities($ele);
                }
            break;
            case ElementStyleTypeEnum::FontSize:
                if(trim($ele) == ""){
                    return '12px';
                }else{
                    return htmlentities($ele.'px');
                }
                break;
            case ElementStyleTypeEnum::widthSize:
                if(trim($ele) == ""){
                    return '98%';
                }else{
                    return htmlentities($ele);
                }
                break;
            case ElementStyleTypeEnum::heightSize:
                if(trim($ele) == "" || trim($ele)=='auto'){
                    return 'auto';
                }else{
                    return htmlentities($ele.'px');
                }
                break;
            case ElementStyleTypeEnum::FontColor:
                if(trim($ele) == ""){
                    return '#000';
                }else{
                    return htmlentities('#'.$ele);
                }
                break;
            case ElementStyleTypeEnum::marginSize:
                if(trim($ele) == ""){
                    return '100px';
                }else{
                    return htmlentities($ele.'px');
                }
                break;
            case ElementStyleTypeEnum::borderSize:
                if(trim($ele) == ""){
                    return '2px';
                }else{
                    return htmlentities($ele.'px');
                }
                break;
        }

    }

    private function set_formdata($row){
        $divstylearray = $this->explodestyle($row->eotmaindivstyles);
        $eotstylearray = $this->explodestyle($row->eotheaderstyles);
        $labelstylearray = $this->explodestyle($row->optionlabelstyle);
        $optionlabela = explode('|',$row->optionlabela);
        $optionlabelb = explode('|',$row->optionlabelb);
        $optionlabelc = explode('|',$row->optionlabelc);
        $optionlabeld = explode('|',$row->optionlabeld);
        $formdata =  array(
            'formaction'=>BASEURL.'/cp.php?c=Dashboard&m=update',
            'eid'=>$row->id,
            'allowcustomreason' => html_entity_decode($row->allowcustomreason),
            'exiturl' => html_entity_decode($row->exiturl),
            'exitsplashpage'=>html_entity_decode($row->exitsplashpage),
            'feedbackbutton'=>html_entity_decode($row->feedbackbutton),
            'isfeedbackbuttonimage'=>html_entity_decode($row->isfeedbackbuttonimage),
            'feedbackbuttonimageurl'=>html_entity_decode($row->feedbackbuttonimageurl),
            'poweredby'=>html_entity_decode($row->poweredby),
            'poweredbylink'=>html_entity_decode($row->poweredbylink),
			'poweredbycolor'=>html_entity_decode($row->poweredbycolor),
            'alertmessage' =>html_entity_decode($row->alerttext),
            'breakevery' => html_entity_decode($row->breakevery),
            'eotbox_width' => $divstylearray['width'] ,
            'eotbox_height' => str_replace('px','', $divstylearray['height']),
            'eotbox_margin-top' => str_replace('px','', $divstylearray['margin-top']),
            'eotbox_background-color' => str_replace('#','', $divstylearray['background-color']),
            'eotbox_border' => str_replace('px','', $divstylearray['border-width']),
            'eotbox_border-color' => str_replace('#','', $divstylearray['border-color']),
            'eottitle' =>$row->eottitle,
            'eotheader_font-size' => str_replace('px','',$eotstylearray['font-size']),
            'eotheader_font-family' => $eotstylearray['font-family'],
            'eotheader_color' => str_replace('#','',$eotstylearray['color']),
            'eotheader_background-color' => str_replace('#','',$eotstylearray['background-color']),
            'optionlabela' => $optionlabela[0],
            'optionvaluea' => $optionlabela[1],
            'optionlabelb' => $optionlabelb[0],
            'optionvalueb' => $optionlabelb[1],
            'optionlabelc' => $optionlabelc[0],
            'optionvaluec' => $optionlabelc[1],
            'optionlabeld' => $optionlabeld[0],
            'optionvalued' => $optionlabeld[1],
            'emailvaluelabel'=> html_entity_decode($row->emailvaluelabel),
            'awebera'=> html_entity_decode($row->awebera),
            'aweberb'=> html_entity_decode($row->aweberb),
            'aweberc'=> html_entity_decode($row->aweberc),
            'aweberd'=> html_entity_decode($row->aweberd),
            'awebercustom'=> html_entity_decode($row->awebercustom),
            'label_font-family' => $labelstylearray['font-family'],
            'label_font-size' => str_replace('px','',$labelstylearray['font-size']),
            'label_font-color' => str_replace('#','',$labelstylearray['color']),
        );

        return $formdata;
    }

    private function explodestyle($style){
        $_style = explode(';',$style);
        $_styles = array();
        foreach ($_style as $_s) {
            if(trim($_s) != ''){
                $st = explode(':',$_s);
                $_styles[$st[0]] = $st[1];
            }
        }

        return $_styles;
    }

}

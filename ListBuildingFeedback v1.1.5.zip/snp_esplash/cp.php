<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Zero
 * Date: 3/1/13
 * Time: 12:09 PM
 * To change this template use File | Settings | File Templates.
 */


include dirname(__FILE__).'/core/config.php';

$controller = (isset($_GET["c"])) ? strtolower($_GET["c"]) : "login";
$method = (isset($_GET["m"])) ? strtolower($_GET["m"]) : "index";
$content='';
$title='';
require_once "core/core.php";
include_once CONTROLLERPATH."/$controller".EXT;
$class = new $controller();
try{
    $class->method_call($class,$method);
}catch (Exception $e){
    echo $e;
}



<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Zero
 * Date: 2/22/13
 * Time: 8:20 AM
 * To change this template use File | Settings | File Templates.
 */?>




<div class="exitoption">
    <img src="/wpeerexitsplash/wpeerloader/images/close.png" alt="" class="wpeer-exitoption-close-button">
    <div class="wpeer-exitoption-title">
        <h1>Exit option Title</h1>
    </div>
    <div style="margin-left: 50px">
        <p>OPtion 1</p>
        <p>OPtion 1</p>
        <p>OPtion 1</p>
        <p>OPtion 1</p>
    </div>
</div>
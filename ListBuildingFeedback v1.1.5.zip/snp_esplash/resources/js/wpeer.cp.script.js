/**
 * Created with JetBrains PhpStorm.
 * User: Zero
 * Date: 2/21/13
 * Time: 6:10 PM
 * To change this template use File | Settings | File Templates.
 */


var wpeer = {};
wpeer.query = jQuery.noConflict(true);
wpeer.query.extend({postJSON:function(url,data,callback){return jQuery.post(url,data,callback,"json")}});
wpeer.query.extend({cElement:function(e){
    if(wpeer.query('#'+ e.elId).length == 0){
        switch (e.elName){
            case "div":
                wpeer.query('<'+e.elName+'/>', {
                    id:e.elId
                }).css(e.eStyle).appendTo(e.eAppendTo);
                break;
            case "img":
                wpeer.query('<'+e.elName+'/>', {
                    id:e.elId,
                    alt:e.eAlt,
                    src:e.eSrc
                }).css(e.eStyle).appendTo(e.eAppendTo);
                break;
        }
    }
}});

wpeer.query.extend({addElementEvent:function(e,event,callback){
    wpeer.query(e).live(event,callback);
}});
wpeer.query(function() {
    wpeer.query.fn.reverse = [].reverse;
    var url= baseurl;//'http://'+window.location.hostname;
    var imgsource = url +'/resources/images/';
    var mEngine = {
        elprefix:'wpeer',
        ui:{
            styles:function(){
                if(typeof mEngine.ui.styles._initialized == "undefined") {

                    mEngine.ui.styles.prototype.colorpick = function(){
                        wpeer.query('.clrpicker').ColorPicker({
                            onSubmit: function(hsb, hex, rgb, el) {
                                wpeer.query(el).val(hex);
                                wpeer.query(el).ColorPickerHide();
                                wpeer.query(el).css({borderColor:'#'+hex});
                            },
                            onBeforeShow: function () {
                                wpeer.query(this).ColorPickerSetColor(this.value);
                            }
                        })
                            .bind('keyup', function(){
                                wpeer.query(this).ColorPickerSetColor(this.value);
                            });
                    };

                    mEngine.ui.styles.prototype.init = function(){
                        var self = this;
                        self.colorpick();
                    };
                    mEngine.ui.styles._initialized = true;
                }
                this.init();
            },

            eEvent:function(){
                if(typeof mEngine.ui.eEvent._initialized == "undefined") {

                    mEngine.ui.eEvent.prototype.optionCheckEvent= function(){
                        var self = this;
                        wpeer.query('.optioncheck').delegate(wpeer.query(this),'change',function(e){
                            self.checkstate(wpeer.query(this));
                        });
                    };

                    mEngine.ui.eEvent.prototype.initCheckState = function(){
                        var self = this;
                        wpeer.query('.optioncheck').each(function(){
                            self.checkstate(wpeer.query(this));
                        });


                    };

                    mEngine.ui.eEvent.prototype.checkstate = function($el){
                        var $elname = $el.attr('name');
                        var $el_index = $elname.split('_');
                        if($el.is(':checked')){

                            wpeer.query('.'+$elname).find('input, textarea').removeAttr('disabled');
                            wpeer.query('.optiongroup'+$el_index[1]).find('input, textarea').removeAttr('disabled');
                        }else{
                            wpeer.query('.'+$elname).find('input, textarea').attr('disabled', 'disabled');
                            wpeer.query('.optiongroup'+$el_index[1]).find('input, textarea').attr('disabled', 'disabled');

                        }
                    };

                    mEngine.ui.eEvent.prototype.uibuttonEvent = function(){
                        var self = this;
                        wpeer.query('.uibutton').delegate(wpeer.query(this),'click',function(){
                            if(wpeer.query(this).hasClass('preview')){
                                self.builpreview();
                            }

                            if(wpeer.query(this).hasClass('deletebtn')){
                                var cnt = 0;
                                var $b = wpeer.query('.echeck');
                                if($b.filter(':checked').length == 0){
                                    alert('Please select item you want to delete');
                                }else{
                                    if(confirm("Are you sure you want to delete selected items?")==true){
                                        wpeer.query('#deleteitemlist').submit();
                                    }
                                }
                            }
                        });
                    };

                    mEngine.ui.eEvent.prototype.builpreview = function(){
                        var $eottile = wpeer.query('.wpeer-exitoption-title');
                        /*HEADER*/
                        var style = {
                            fontSize:wpeer.query('input[name="eotheader_font-size"]').val()+'px',
                            fontFamily:wpeer.query('.eotheader_font-family').val(),
                            color:'#'+wpeer.query('input[name="eotheader_color"]').val(),
                            backgroundColor:'#'+wpeer.query('input[name="eotheader_background-color"]').val()
                        };
                        $eottile.find('h1').text(wpeer.query('input[name="eottitle"]').val());
                        $eottile.find('h1').css({'fontSize':style.fontSize})
                        $eottile.css(style);

                        /*BOX*/
                        style = {
                            marginTop:wpeer.query('input[name="eotbox_margin-top"]').val()+'px',
                            width:wpeer.query('input[name="eotbox_width"]').val(),
                            height:wpeer.query('input[name="eotbox_height"]').val()+'px',
                            borderWidth:wpeer.query('input[name="eotbox_border"]').val()+'px',
                            borderColor:'#'+wpeer.query('input[name="eotbox_border-color"]').val(),
                            backgroundColor:'#'+wpeer.query('input[name="eotbox_background-color"]').val()
                        };
                        wpeer.query('.wpeer-exit-option-wrap').css(style);

                        /*OPTION BOX*/
                        wpeer.query('.optionlbl').each(function(ind){
                            var $el = wpeer.query(this);
                            var $elname = $el.attr('name');
                            var $el_index = $elname.split('_');
                            if($el.val().trim() != ''){
                                wpeer.query('.wpeer-option-element-wrap').append(
                                    '<p><input type="radio" ind="'+ (parseInt(ind) + 1) +'" name="optionradio" ><label style="font-family:'+wpeer.query('.label_font-family').val()+' ;color:#'+wpeer.query('input[name="label_font-color"]').val()+';font-size:'+wpeer.query('input[name="label_font-size"]').val()+'px'+'">'+ $el.val() +'</label></p>'
                                );
                            }
                        });

                        /*CUSTOM REASON*/
                        if(wpeer.query('input[name="allowcustomreason"]').is(':checked')){
                            wpeer.query('.wpeer-option-element-wrap').append(
                                '<p><input type="radio" class="customreasonRadio" name="optionradio" /> <label style="font-family:'+wpeer.query('.label_font-family').val()+' ;color:#'+wpeer.query('input[name="label_font-color"]').val()+';font-size:'+wpeer.query('input[name="label_font-size"]').val()+'px; margin-right: 10px;display: inline-block; " for="wpeercustomreason">Others Reason: </label></p>'
                            );
                        }

						var butt = (wpeer.query.trim(wpeer.query('input[name="feedbackbuttonimageurl"]').val())!="") ? "<a class='wpeer-trace-button wpeer-ui-button-image-flash' href='#'><img src='"+ wpeer.query.trim(wpeer.query('input[name="feedbackbuttonimageurl"]').val()) +"' alt=''></a>" : "<a class='wpeer-trace-button' href='#'>"+ wpeer.query('input[name="feedbackbutton"]').val() +"</a>";
                        if(wpeer.query.trim(wpeer.query('textarea[name="emailvaluelabel"]').val())=="" && wpeer.query.trim(wpeer.query('input[name="feedbackbutton"]').val()) != ""){
                            wpeer.query('.wpeer-option-element-wrap').append(
                                butt
                            );
                        }

                        /*AWEBER BOX*/
                        wpeer.query('.wpeer-option-element-wrap').append(
                            wpeer.query('textarea[name="emailvaluelabel"]').val()
                        );

                        if(wpeer.query.trim(wpeer.query('input[name="poweredby"]').val()) !== ""){
                            console.log(wpeer.query.trim(wpeer.query('input[name="poweredby"]').val()) !== "");
                            wpeer.query('.wpeer-exit-option-wrap').append(
                                '<div class="'+mEngine.elprefix+'-poweredby"><a style="color:#'+ wpeer.query('input[name="poweredbycolor"]').val() +'" target="_blank" href="'+ wpeer.query('input[name="poweredbylink"]').val() +'">Powered by: '+ wpeer.query('input[name="poweredby"]').val() +'</a></div>'
                            );
                        }

                        wpeer.query(window.parent.document).scrollTop(0);
                        wpeer.query('.wpeer-overlay, .wpeer-exit-option-wrap').show();

                        var h = wpeer.query('.wpeer-exit-option-wrap').height();
                        wpeer.query('input[name="optionradio"]').live('change',function(){
                            wpeer.query('.optin').remove();
                            wpeer.query('.wpeer-trace-button').hide();
                            if(wpeer.query(this).attr('class')=='customreasonRadio'){
                                if(wpeer.query('.wpeer-trace-button').length){
                                    wpeer.query('.wpeer-trace-button').before(
                                        '<div class="optin"><p><label style="padding: 10px 0; float:left;margin-right: 10px;display: block;" for="'+mEngine.elprefix+'customreason">Enter your Reason: </label><input style="width:95%" type="text" name="wpeercustomreason"  id="wpeercustomreason" /></p>'+
                                            wpeer.query('textarea[name="awebercustom"]').val()
                                            +'</div>'
                                    );
                                }else{
                                    wpeer.query('.wpeer-option-element-wrap').append(
                                        '<div class="optin"><p><label style="padding: 10px 0; float:left;margin-right: 10px;display: block;" for="'+mEngine.elprefix+'customreason">Enter your Reason: </label><input style="width:95%" type="text" name="wpeercustomreason"  id="wpeercustomreason" /></p>'+
                                            wpeer.query('textarea[name="awebercustom"]').val()
                                            +'</div>'
                                    );
                                }

                                /*if(!wpeer.query('#wpeer-button-aweber').length){
                                    wpeer.query('.wpeer-trace-button').show();
                                }*/
                            }else{
                                var elm = '.optiongroup'+ wpeer.query(this).attr('ind');
                                if(wpeer.query('textarea[name="awebera"]') != ""){
                                    if(wpeer.query('.wpeer-trace-button').length){
                                        wpeer.query('.wpeer-trace-button').before(
                                            '<div class="optin">'+
                                                wpeer.query(elm).find('textarea').val()
                                                +'</div>'
                                        );
                                    }else{
                                        wpeer.query('.wpeer-option-element-wrap').append(
                                            '<div class="optin">'+
                                                wpeer.query(elm).find('textarea').val()
                                                +'</div>'
                                        );
                                        /*wpeer.query('.wpeer-trace-button').show();*/
                                    }
                                }
                            }
                        });

                    }

                    mEngine.ui.eEvent.prototype.closeelementEvent = function(){
                        wpeer.query('.'+mEngine.elprefix+'-form_error').find('a').delegate(wpeer.query(this),'click',function(){
                            wpeer.query('.'+mEngine.elprefix+'-form_error').remove();
                        });

                        wpeer.query('.aformgenwrap').find('a').delegate(wpeer.query(this),'click',function(){
                            wpeer.query('.aformgenwrap').remove();
                        });

                        wpeer.query('.'+mEngine.elprefix+'-exitoption-close-button, .'+mEngine.elprefix+'-overlay').delegate(wpeer.query(this),'click',function(){
                            wpeer.query('.wpeer-option-element-wrap').html("");
                            wpeer.query('.wpeer-poweredby').remove();
                            wpeer.query('.'+mEngine.elprefix+'-overlay, .'+mEngine.elprefix+'-exit-option-wrap').hide();

                        });
                    };

                    mEngine.ui.eEvent.prototype.copyclipboard = function(){
                        ZeroClipboard.setMoviePath(url+'/resources/component/zeroclipboard/ZeroClipboard.swf');

                        var clip = new ZeroClipboard.Client();
                        clip.addEventListener('mousedown',function() {
                            clip.setText(document.getElementById('aformgentxt').value);
                        });
                        clip.addEventListener('complete',function(client,text) {
                            wpeer.query('.copyclipboard').text('Copied');
                        });

                        clip.glue('copyclipboard');
                    }
					
					mEngine.ui.eEvent.prototype.AllowScripttoAllLinks = function(){
                        wpeer.query('.allow-all').delegate(wpeer.query(this),'change',function(){
                            if(wpeer.query(this).is(':checked')){
								wpeer.query('input[name="exiturl"]').val('DEFAULTURL').attr("readonly", "readonly");
							}else{
								wpeer.query('input[name="exiturl"]').val('').removeAttr("readonly"); 
							}
                        });
                    }
					
                    mEngine.ui.eEvent.prototype.init = function(){
                        var self = this;
                        self.initCheckState();
                        self.optionCheckEvent();
                        self.uibuttonEvent();
                        self.closeelementEvent();
						self.AllowScripttoAllLinks();
                        if(wpeer.query('#aformgentxt').length){
                            self.copyclipboard();
                        }
                    };
                    mEngine.ui.eEvent._initialized = true;
                }
                this.init();
            },

            dom:function(){
                if(typeof mEngine.ui.dom._initialized == "undefined") {


                    mEngine.ui.dom.prototype.init = function(){};
                    mEngine.ui.dom._initialized = true;
                }
                this.init();
            },
            domEvent:function(){
                if(typeof mEngine.ui.domEvent._initialized == "undefined") {



                    mEngine.ui.domEvent.prototype.init = function(){};
                    mEngine.ui.domEvent._initialized = true;
                }
                this.init();
            }
        }
    }

    new mEngine.ui.styles();
    new mEngine.ui.eEvent();
});
/**
 * Created with JetBrains PhpStorm.
 * User: Zero
 * Date: 2/21/13
 * Time: 6:10 PM
 * To change this template use File | Settings | File Templates.
 */

    
var wpeer = {};
wpeer.query = jQuery.noConflict(true);
wpeer.query.extend({postJSON:function(url,data,callback){return jQuery.post(url,data,callback,"json")}});
wpeer.query.extend({cElement:function(e){
    if(wpeer.query('#'+ e.elId).length == 0){
        switch (e.elName){
            case "div":
                wpeer.query('<'+e.elName+'/>', {
                    id:e.elId
                }).css(e.eStyle).appendTo(e.eAppendTo);
                break;
            case "img":
                wpeer.query('<'+e.elName+'/>', {
                    id:e.elId,
                    alt:e.eAlt,
                    src:e.eSrc
                }).css(e.eStyle).appendTo(e.eAppendTo);
                break;
        }
    }
}});

wpeer.query.extend({addElementEvent:function(e,event,callback){
    wpeer.query(e).live(event,callback);
}});
wpeer.query(function() {
    wpeer.query.fn.reverse = [].reverse;
    var url='http://'+window.location.hostname;
    var imgsource = url +'/esplash/resources/images/';
    var mEngine = {
        elprefix:'wpeer',
        isExitSplash:true,
        isExitSplashOption:true,
        hasChanged:false,
        appLibrary:{
            EXITMESSAGE:"exit message",
            OPTIONTITLE : "Title Here",
            LABELOPTIONA: "Label Option A",
            LABELOPTIONB: "Label Option B",
            LABELOPTIONC: "Label Option C",
            LABELOPTIOND: "Label Option D",
            CHECKOPTION: "Check options",
            EOTMAINDIVSTYLE:"",
            EOTTITLEDIVSTYLE:"",
            EOTHEADERSTYLE:"",
            EOTOPTIONLABELSTYLE:"",
            EOTTHEME:""
        },
        ui:{
            dom:function(){
                if(typeof mEngine.ui.dom._initialized == "undefined") {
                    mEngine.ui.dom.prototype.overlay=function(){
                        //Create Overlay
                        if(!mEngine.isExitSplashOption)return;
                        if(wpeer.query('#'+mEngine.elprefix+'overlay').length == 0){
                            wpeer.query('<div/>', {
                                id: mEngine.elprefix+'overlay'
                            }).addClass(mEngine.elprefix+'-overlay').appendTo('body');
                        }
                    };

                    mEngine.ui.dom.prototype.exitoption=function(){
                        if(!mEngine.isExitSplashOption)return;
                        if(wpeer.query('#'+mEngine.elprefix+'-exit-option-wrap').length == 0){
                            mEngine.isExitSplashOption=false;

                            $exitDiv = wpeer.query('<div/>', {
                                id: mEngine.elprefix+'-exit-option-wrap'
                            }).addClass(mEngine.elprefix+'-exit-option-wrap').appendTo('body').attr('style',mEngine.appLibrary.EOTMAINDIVSTYLE);

                            $exitDiv.append('<img src="'+ imgsource +'close.png" alt="" class="'+ mEngine.elprefix +'-exitoption-close-button">');
                            $exitDiv.append('<div class="'+ mEngine.elprefix +'-exitoption-title" style="'+mEngine.appLibrary.EOTTITLEDIVSTYLE +'">' +
                                '<h1 style="'+ mEngine.appLibrary.EOTHEADERSTYLE +'" >'+mEngine.appLibrary.OPTIONTITLE+'</h1>' +
                                '</div>' +
                                '<div class="'+mEngine.elprefix+'-option-element-wrap '+ mEngine.appLibrary.EOTTHEME +'">' +
                                '<p><input type="radio" name="radioptions" id="'+mEngine.elprefix+'radioptionsA"><label style="'+mEngine.appLibrary.EOTOPTIONLABELSTYLE+'" for="'+mEngine.elprefix+'radioptionsA">'+mEngine.appLibrary.LABELOPTIONA+'</label></p>' +
                                '<p><input type="radio" name="radioptions" id="'+mEngine.elprefix+'radioptionsB"><label style="'+mEngine.appLibrary.EOTOPTIONLABELSTYLE+'" for="'+mEngine.elprefix+'radioptionsB">'+mEngine.appLibrary.LABELOPTIONB+'</label></p>' +
                                '<p><input type="radio" name="radioptions" id="'+mEngine.elprefix+'radioptionsC"><label style="'+mEngine.appLibrary.EOTOPTIONLABELSTYLE+'" for="'+mEngine.elprefix+'radioptionsC">'+mEngine.appLibrary.LABELOPTIONC+'</label></p>' +
                                '<p><input type="radio" name="radioptions" id="'+mEngine.elprefix+'radioptionsD"><label style="'+mEngine.appLibrary.EOTOPTIONLABELSTYLE+'" for="'+mEngine.elprefix+'radioptionsD">'+mEngine.appLibrary.LABELOPTIOND+'</label></p>' +
                                '<p><input type="checkbox" name="checkoptions" id="'+mEngine.elprefix+'checkoptions"><label style="'+mEngine.appLibrary.EOTOPTIONLABELSTYLE+'" for="'+mEngine.elprefix+'checkoptions">'+mEngine.appLibrary.CHECKOPTION+'</label></p>' +
                                '</div>');
                        }
                    }

                    mEngine.ui.dom.prototype.init = function(){};
                    mEngine.ui.dom._initialized = true;
                }
                this.init();
            },
            domEvent:function(){
                if(typeof mEngine.ui.domEvent._initialized == "undefined") {
                    mEngine.ui.domEvent.prototype.closeelementEvent = function(){
                        wpeer.query('.'+mEngine.elprefix+'-exitoption-close-button, #'+mEngine.elprefix+'overlay').live('click',function(){
                            wpeer.query('.'+mEngine.elprefix+'-exitoption-close-button, #'+mEngine.elprefix+'overlay, #'+mEngine.elprefix+'-exit-option-wrap').remove();
                        });
                    };

                    mEngine.ui.domEvent.prototype.init = function(){};
                    mEngine.ui.domEvent._initialized = true;
                }
                this.init();
            }
        },
        proc:{
            wsplasher:function(){
                this.dom = new mEngine.ui.dom();
                this.domevent = new mEngine.ui.domEvent();
                if(typeof mEngine.proc.wsplasher._initialized == "undefined") {

                    mEngine.proc.wsplasher.prototype.TryToleaveEvent=function(){
                        var self = this;
                        wpeer.query(document).bind('mouseleave',function(){
                            if(mEngine.isExitSplashOption){
                                self.dom.overlay();
                                self.dom.exitoption();
                                self.domevent.closeelementEvent();

                                /*wpeer.query.addElementEvent(wpeer.query('.wpeer-exitoption-close-button'),'click',function(){
                                    wpeer.query('#wpeerSplashOverlay, .wpeer-exitoption-close-button, .exitoption').remove();
                                    mEngine.isExitSplashOption = false;
                                });*/
                            }
                        });
                    };

                    mEngine.proc.wsplasher.prototype.winunloader = function(){
                        var self = this;
                        wpeer.query(window).bind('beforeunload', function(){
                            if(mEngine.isExitSplash){
                                self.exitSplashMethod();
                                return mEngine.appLibrary.EXITMESSAGE;
                            }
                        });
                    };

                    mEngine.proc.wsplasher.prototype.exitSplashMethod = function(){
                        var self = this;
                        mEngine.isExitSplash = false;
                        window.scrollTo(0,0);
                        var isChrome = navigator.userAgent.toLowerCase().indexOf('chrome') > -1;
                        wpeer.query('#wpeerSplashOverlay, .wpeer-exitoption-close-button, .exitoption').remove();
                        self.createExitSPlasher();
                        window.alert(mEngine.appLibrary.EXITMESSAGE);

                    };



                    mEngine.proc.wsplasher.prototype.overlayCreator=function(){
                        //Create Overlay
                        if(wpeer.query('#wpeerSplashOverlay').length == 0){
                            wpeer.query('<div/>', {
                                id: 'wpeerSplashOverlay'
                            }).css(mEngine.appLibrary.OVERLAYSTYLE).appendTo('body');
                        }
                    };

                    mEngine.proc.wsplasher.prototype.createExitSPlasher=function(){
                        mEngine.isExitSplashOption = false;
                        var exitsplashpage = "http://makemoneyonlinewithkev.com/"
                        var theDiv = '<div id="ExitSplashDiv"  style=" display:block; width:100%; height:100%; position:absolute; background:#FFFFFF; margin-top:0px; margin-left:0px;" align="center">';
                        theDiv = theDiv + '<div id="ExitCancelButtonImageDiv" style="background: #000; width: 100%;" align="left"><img src="/esplash/resources/images/close.jpg" border="0"></div>';
                        theDiv = theDiv + '<iframe src="'+exitsplashpage+'" width="100%" height="100%" align="middle" frameborder="0"></iframe>';
                        theDiv = theDiv + '</div>';

                        wpeer.query.cElement({"elName":"div",
                            "elId":"wpeerSplashDivs",
                            "eStyle":{
                                "width":"100%",
                                "height":"100%",
                                "position":"absolute",
                                "top":"0px",
                                "left":"0px",
                                "backgroundColor":"#fff"
                            },
                            "eAppendTo":"body"
                        });
                        wpeer.query('#wpeerSplashDivs').append(theDiv).live('mouseover',function(){
                            wpeer.query('#ExitCancelButtonImageDiv').remove();
                        });

                    };


                    mEngine.proc.wsplasher.prototype.initialize = function(){
                        var self = this;
                        self.winunloader();
                        self.TryToleaveEvent();
                        if (document.createStyleSheet){
                            document.createStyleSheet('/esplash/resources/css/aweberform.classic.css');
                        }
                        else {
                            wpeer.query("head").append(wpeer.query("<link rel='stylesheet' href='/esplash/resources/css/aweberform.classic.css' type='text/css' media='screen' />"));
                        }
                    };
                    mEngine.proc.wsplasher._initialized = true;
                }
                this.initialize();

            }
        }
    }
    mEngine.isExitSplash=true;
    new mEngine.proc.wsplasher();


});

<div id="login">
    <div class="inner">
        <div class="logo" >
            <h1>LOGIN</h1>
        </div>
        <div class="formLogin">
            <form name="formLogin"  id="formLogin" method="POST">

                <div class="tip">
                    <input name="username" type="text"  id="username_id"  title="Username"   />
                </div>
                <div class="tip">
                    <input name="password" type="password" id="password"   title="Password"  />
                </div>

                <div class="loginButton">
                    <div style="float:right; padding:3px 0; margin-right:-12px;">
                        <div>
                            <input type="submit" class="uibutton normal" id="but_login" value="Login">
                        </div>

                    </div>
                    <div class="clear"></div>
                </div>

            </form>
        </div>
    </div>
    <div class="wpeer-clear"></div>
    <div class="shadow"></div>
</div>
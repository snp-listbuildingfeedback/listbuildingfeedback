<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Zero
 * Date: 3/15/13
 * Time: 11:17 AM
 * To change this template use File | Settings | File Templates.
 */
?>
<?php include_once VIEWPATH.'/partial/navigation.php'; ?>
<div id="content" xmlns="http://www.w3.org/1999/html">
    <div class="inner">
        <div class="widget">
            <div class="header"><span><span class="ico gray record"></span>  REPORT  </span></div>
            <div class="content">
                <form action="" method="post" id="aformgen">
                    <div class="boxtitle"><span class="ico gray list"></span>
                        OPTION REPORT
                    </div>
                    <div class="section" >
                        <table class="display data_table2" >
                            <thead>
                            <tr>
                                <th><div class="th_wrapp">Link Url</div></th>
                                <th><div class="th_wrapp">Option Value</div></th>
                                <th><div class="th_wrapp">Other Reason</div></th>
                                <th><div class="th_wrapp">Count</div></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php
                            if($reportlist){
                                foreach($reportlist as $list):?>

                                    <tr>
                                        <td><?php echo $list->exiturl ?></td>
                                        <td><?php echo $list->description ?></td>
                                        <td><?php echo $list->customdescription ?></td>
                                        <td><?php echo $list->total ?></td>
                                    </tr>
                                <?php endforeach; }?>
                            </tbody>
                        </table>
                    </div>

                </form>
            </div>
        </div>
    </div>
</div>
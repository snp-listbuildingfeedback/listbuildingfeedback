<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Zero
 * Date: 3/12/13
 * Time: 6:46 PM
 * To change this template use File | Settings | File Templates.
 */

?>
<?php include_once VIEWPATH.'/partial/navigation.php'; ?>
<div id="content">
    <div class="inner"  style="margin-bottom: 20px">
        <div class="widget">
            <div class="header"><span><span class="ico gray window"></span>  List Building Feedback LIST   </span></div>
            <div class="content">
                <div class="tableName">
                <a class="uibutton special deletebtn"  href="#">Delete selected</a>
                <form method="post" action="/esplash/cp.php?c=Dashboard&m=deletelist" id="deleteitemlist">
                <table class="display data_table2" >
                    <thead>
                    <tr>
                        <th><div class="th_wrapp">&nbsp;</div></th>
                        <th><div class="th_wrapp">Link Url</div></th>
                        <th><div class="th_wrapp">Header</div></th>
                        <th><div class="th_wrapp">Created At</div></th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php
                        if($splashlist){
                        foreach($splashlist as $list):?>

                            <tr>
                                <td><input type="checkbox" value="<?php echo $list->id ?>" class="echeck" name="echeck[]"></td>
                                <td><a href="<?php echo BASEURL?>/cp.php?c=Dashboard&m=profile&eid=<?php echo $list->id ?>&ran=<?php echo wp_generate_password() ?>"><?php echo $list->exiturl?></a></td>
                                <td><?php echo $list->eottitle ?></td>
                                <td><?php echo $list->createdat ?></td>
                            </tr>
                        <?php endforeach; }?>
                    </tbody>
                </table>
                </form>
                <a class="uibutton special deletebtn" href="#" >Delete selected</a>
                </div>
            </div>
        </div>
    </div>
</div>
<div style="width: 100%; display: block; height: 50px"></div>
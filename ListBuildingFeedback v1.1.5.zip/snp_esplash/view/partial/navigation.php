<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Zero
 * Date: 3/12/13
 * Time: 6:52 PM
 * To change this template use File | Settings | File Templates.
 */
?>
<div class="widget">
    <div class="header">
        <!--<span>Hi <?php /*echo $user */?> </span>-->
        <span><a class="<?php echo ($actives == 'index') ? "actives" :"" ?>" href="<?php echo BASEURL ?>/cp.php?c=Dashboard&m=index&ran=<?php echo wp_generate_password() ?>">ESplash List</a></span>
        <span><a class="<?php echo ($actives == 'addesplash') ? "actives" :"" ?>" href="<?php echo BASEURL ?>/cp.php?c=Dashboard&m=addesplash&ran=<?php echo wp_generate_password() ?>">Add ESplash</a></span>
        <span><a class="<?php echo ($actives == 'formgenerator') ? "actives" :"" ?>" href="<?php echo BASEURL ?>/cp.php?c=Dashboard&m=formgenerator&ran=<?php echo wp_generate_password() ?>">Form Generator</a></span>
        <span><a class="<?php echo ($actives == 'report') ? "actives" :"" ?>" href="<?php echo BASEURL ?>/cp.php?c=Dashboard&m=report&ran=<?php echo wp_generate_password() ?>">Report</a></span>
    </div><!-- End header -->
</div>

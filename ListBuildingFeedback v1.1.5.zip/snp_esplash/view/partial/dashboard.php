<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Zero
 * Date: 3/1/13
 * Time: 1:01 PM
 * To change this template use File | Settings | File Templates.
 */
?>

<?php include_once VIEWPATH.'/partial/navigation.php'; ?>
<div id="content" xmlns="http://www.w3.org/1999/html">
    <div class="inner">
        <div class="widget">
            <div class="header"><span><span class="ico gray window"></span>  List Building Feedback Elements  </span>

            </div><!-- End header -->
            <div class="content">
                <form action="<?php echo $this->set_value('formaction') ?>#" method="post">
                    <?php if(isset($includescript)){ ?>
                    <div class="boxtitle"><span class="ico gray hammer"></span>
                        INCLUDE SCRIPT
                    </div>
                    <div class="section" >
                        <div class="esplash_copy_script">
                            <label>Paste this script on the corresponding link.</label>
                            <label style="display: block;color: #ff4500"><br/>FOR HTML</label>
                            <p>&lt;!--/**************************************************************************************/--&gt;</p>
                            <p>&lt;script src="<?php echo BASEURL ?>/resources/js/jquery-1.8.2.js">&lt;/script&gt;</p>
                            <p>&lt;script src="<?php echo BASEURL ?>/wpeersplasher.php?exit=<?php echo $encryptor->encrypt('exiturlis'.$_GET['eid']) ?>">&lt;/script&gt;</p>
                            <p>&lt;!--/*************************************************************************************/--&gt;</p>

                            <label style="display: block;color: #ff4500"><br/>FOR WORDPRESS</label>
                            <p>[snp_esplash_tag ecode="<?php echo $encryptor->encrypt('exiturlis'.$_GET['eid']) ?>"]</p>
                        </div>
                    </div>
                        <br/>
                    <?php } ?>
                    <div class="boxtitle"><span class="ico gray link"></span>
                        EXIT OPTION BOX WEB LINK
                        <input type="hidden" name="eid" value="<?php echo $this->set_value('eid') ?>">
                        <input type="hidden" name="formaction" value="<?php echo $this->set_value('formaction') ?>">
                    </div>
                    <div class="section" >
                        <label> Link </label>
                        <div> 
						<p style="color:#ff3500;font-weight:bold"><input <?php echo ($this->set_value('exiturl') == "DEFAULTURL") ? "checked='checked'" : ""?> type="checkbox" style="display:inline-block"   name="allowall" class="allow-all" /> Allow to all links?</p>
						<input <?php echo ($this->set_value('exiturl') == "DEFAULTURL") ? "readonly='readonly'" : ""?> value="<?php echo $this->set_value('exiturl') ?>" type="text" name="exiturl" class=" full"  /><span class="f_help">Enter the link where you want to install this script.</span></div>
                        <label> OTO Page Link </label>
                        <div> <input value="<?php echo $this->set_value('exitsplashpage') ?>" type="text" name="exitsplashpage" class=" full"  /><span class="f_help">Enter the link of your OTO</span></div>
                        <label> Powered By </label>
                        <div> <input value="<?php echo $this->set_value('poweredby') ?>" type="text" name="poweredby" class=" full"  /><span class="f_help">Enter affiliate name. (Leave blank if you don't want to show Powered by)</span></div>
                        <label> Powered By Link</label>
                        <div> <input value="<?php echo $this->set_value('poweredbylink') ?>" type="text" name="poweredbylink" class=" full"  /><span class="f_help">Enter affiliate link. (Leave blank if you don't want to show Powered by)</span></div>
						<label> Powered By Font Color</label>
                        <div> <input value="<?php echo $this->set_value('poweredbycolor') ?>" type="text" name="poweredbycolor" class="clrpicker xxsmall" readonly="readonly"  /><span class="f_help">Select font color you want for powered by</span></div>
                    </div>
                    <br/>
                    <div class="boxtitle"><span class="ico gray info2"></span>
                        ALERT BOX MESSAGE
                    </div>
                    <div class="section" >
                        <label> Alert message </label>
                        <div>
                            <input value="<?php echo $this->set_value('alertmessage') ?>" type="text" name="alertmessage" class=" full"  /><span class="f_help">Enter the alert message for the browser's pop up</span>
                            <br/>
                        </div>
                    </div>
                    <br/>
                    <div class="boxtitle"><span class="ico gray window"></span>
                        EXIT OPTION BOX
                    </div>
                    <div class="section" >
                        <label> Exit Option Box Styles </label>
                        <div>
                            <div class="floatleft width200"> <input value="<?php echo $this->set_value('eotbox_width') ?>" type="text" name="eotbox_width" class=" small"  /><span class="f_help">Width (include px or %)</span></div>
                            <div class="floatleft width200"> <input value="<?php echo $this->set_value('eotbox_height') ?>" type="text" name="eotbox_height" class=" small"  /> Pixels<span class="f_help">Heigth (auto if blank)</span></div>
                            <div class="floatleft width200"> <input value="<?php echo $this->set_value('eotbox_margin-top') ?>" type="text" name="eotbox_margin-top" class=" small"  /> Pixels<span class="f_help">Top Margin</span></div>
                            <div class="floatleft width200"> <input value="<?php echo $this->set_value('eotbox_background-color') ?>" type="text" name="eotbox_background-color" class="clrpicker small"  /> <span class="f_help">Background Color</span></div>
                            <div class="floatleft width200"> <input value="<?php echo $this->set_value('eotbox_border') ?>" type="text" name="eotbox_border" class="small"  /> Pixels<span class="f_help">Border Thickness</span></div>
                            <div class="floatleft width200"> <input value="<?php echo $this->set_value('eotbox_border-color') ?>" type="text" name="eotbox_border-color" class="clrpicker small"  /> <span class="f_help">Border Color</span></div>
                        </div>
                        <div class="wpeer-clear"></div>
                    </div>

                    <br/>
                    <div class="boxtitle"><span class="ico gray paragraph_justify"></span>
                        HEADER
                    </div>
                    <div class="section" >
                        <label> Header Title Text </label>
                        <div> <input value="<?php echo $this->set_value('eottitle') ?>" type="text" name="eottitle" class=" full"  /><span class="f_help">Enter text you want to appear on the title bar of the exit option</span></div>
                        <label> Feedback Button </label>
                        <div> <input value="<?php echo $this->set_value('feedbackbutton') ?>" type="text" name="feedbackbutton" class=" full"  /><span class="f_help">Enter text you want to appear on feeback button</span></div>

                        <label>Is Feedback Button Image?</label>
                        <div> <input <?php echo ($this->set_value('isfeedbackbuttonimage')) ? "checked='checked'" : ""?> type="checkbox" style="display:inline-block"   name="isfeedbackbuttonimage" class="allow-all" /></div>

                        <label> Feedback Button Image URL</label>
                        <div> <input value="<?php echo $this->set_value('feedbackbuttonimageurl') ?>" type="text" name="feedbackbuttonimageurl" class=" full"  /><span class="f_help">Enter url of the image for the button</span></div>
                    </div>
                    <div class="section" >
                        <label> Header Title Style </label>
                        <div> <input value="<?php echo $this->set_value('eotheader_font-size') ?>" type="text" name="eotheader_font-size" class=" xxsmall"  /><span class="f_help">Font-Size</span></div>
                        <div>
                            <select name="eotheader_font-family" data-placeholder="Choose a Font..." class="cust-select eotheader_font-family" tabindex="2" >
                                <option <?php echo ($this->set_value('eotheader_font-family')=='Arial') ? 'selected="selected"' : ""  ?> value="Arial">Arial</option>
                                <option <?php echo ($this->set_value('eotheader_font-family')=="Calibri, Candara, Segoe, 'Segoe UI', Optima, Arial, sans-serif") ? 'selected="selected"' : ""  ?> value="Calibri, Candara, Segoe, \'Segoe UI\', Optima, Arial, sans-serif">Calibri</option>
                                <option <?php echo ($this->set_value('eotheader_font-family')=='Helvetica') ? 'selected="selected"' : ""  ?> value="Helvetica">Helvetica</option>
                                <option <?php echo ($this->set_value('eotheader_font-family')=='Tahoma') ? 'selected="selected"' : ""  ?> value="Tahoma">Tahoma</option>
                                <option <?php echo ($this->set_value('eotheader_font-family')=='Times New Roman') ? 'selected="selected"' : ""  ?> value="Times New Roman">Times New Roman</option>
                            </select>
                            <span class="f_help">Font-Family</span>
                        </div>
                        <div> <input value="<?php echo $this->set_value('eotheader_color') ?>" type="text" name="eotheader_color" maxlength="6" size="6" class="clrpicker xxsmall"  /><span class="f_help">Font Color</span></div>
                        <div> <input value="<?php echo $this->set_value('eotheader_background-color') ?>" type="text" name="eotheader_background-color" class="clrpicker xxsmall"  /><span class="f_help">Background Color</span></div>
                    </div>
                    <br/>
                    <div class="boxtitle"><span class="ico gray list"></span>
                        LABELS
                    </div>
                    <div class="section">
                        <label>Allow custom reason</label>
                        <div><input <?php echo ($this->set_value('allowcustomreason')) ? "checked='checked'" : ""?> type="checkbox" style="display:inline-block"   name="allowcustomreason" class="allow-all" /> </div>
                        <div class="optioncustom">
                            <textarea name="awebercustom"><?php echo str_replace('\"','"',$this->set_value('awebercustom')) ?></textarea><span class="f_help">Optin form for custom reason</span>
                            <a href="#" class="pop" onclick="javascript:window.open('<?php echo plugins_url()?>/snp_esplash/cp.php?c=Dashboard&m=formgenerator&ran=<?php echo wp_generate_password()?>','Form Generator','height=' + screen.height + ',width=900,resizable=yes,scrollbars=yes')">Open Form Generator</a>
                        </div>
                    </div>
                    <div class="section" >
                        <label> Option 1 </label>
                        <div class="optiongroup1">
                            <input value="<?php echo $this->set_value('optionvaluea') ?>" type="text" name="optionlabela" class=" medium optionlbl"  /><span class="f_help">Enter text for the first option</span>
                            <textarea name="awebera"><?php echo str_replace('\"','"',$this->set_value('awebera')) ?></textarea><span class="f_help">Optin form for this option</span>
                            <a href="#" class="pop" onclick="javascript:window.open('<?php echo plugins_url()?>/snp_esplash/cp.php?c=Dashboard&m=formgenerator&ran=<?php echo wp_generate_password()?>','Form Generator','height=' + screen.height + ',width=900,resizable=yes,scrollbars=yes')">Open Form Generator</a>
                        </div>
                    </div>
                    <div class="section" >
                        <label> Option 2 </label>
                        <div class="optiongroup2">
                            <input value="<?php echo $this->set_value('optionlabelb') ?>" type="text" name="optionlabelb" class=" medium  optionlbl"  /><span class="f_help">Enter text for the second option</span>
                            <textarea name="aweberb"><?php echo str_replace('\"','"',$this->set_value('aweberb')) ?></textarea><span class="f_help">Optin form for this option</span>
                            <a href="#" class="pop" onclick="javascript:window.open('<?php echo plugins_url()?>/snp_esplash/cp.php?c=Dashboard&m=formgenerator&ran=<?php echo wp_generate_password()?>','Form Generator','height=' + screen.height + ',width=900,resizable=yes,scrollbars=yes')">Open Form Generator</a>
                        </div>
                    </div>
                    <div class="section" >
                        <label> Option 3 </label>
                        <div class="optiongroup3">
                            <input value="<?php echo $this->set_value('optionlabelc') ?>" type="text" name="optionlabelc" class=" medium optionlbl"  /><span class="f_help">Enter text for the third option</span>
                            <textarea name="aweberc"><?php echo str_replace('\"','"',$this->set_value('aweberc')) ?></textarea><span class="f_help">Optin form for this option</span>
                            <a href="#" class="pop" onclick="javascript:window.open('<?php echo plugins_url()?>/snp_esplash/cp.php?c=Dashboard&m=formgenerator&ran=<?php echo wp_generate_password()?>','Form Generator','height=' + screen.height + ',width=900,resizable=yes,scrollbars=yes')">Open Form Generator</a>
                        </div>
                    </div>
                    <div class="section" >
                        <label> Option 4 </label>
                        <div class="optiongroup4">
                            <input value="<?php echo $this->set_value('optionlabeld') ?>" type="text" name="optionlabeld" class=" medium optionlbl"  /><span class="f_help">Enter text for the fourth option</span>
                            <textarea name="aweberd"><?php echo str_replace('\"','"',$this->set_value('aweberd')) ?></textarea><span class="f_help">Optin form for this option</span>
                            <a href="#" class="pop" onclick="javascript:window.open('<?php echo plugins_url()?>/snp_esplash/cp.php?c=Dashboard&m=formgenerator&ran=<?php echo wp_generate_password()?>','Form Generator','height=' + screen.height + ',width=900,resizable=yes,scrollbars=yes')">Open Form Generator</a>
                        </div>
                    </div>
                    <div class="section" style="display: none">
                        <label> Email Options</label>
                        <div class="emailptions">
                            <textarea name="emailvaluelabel"><?php echo str_replace('\"','"',$this->set_value('emailvaluelabel')) ?></textarea>
                        </div>
                    </div>
                    <div class="section" >
                        <label>Style</label>
                        <div >
                            <div class="floatleft width200">
                                <select name="label_font-family" data-placeholder="Choose a Font..." class="cust-select label_font-family" tabindex="2" >
                                    <option <?php echo ($this->set_value('label_font-family')=='Arial') ? 'selected="selected"' : ""  ?> value="Arial">Arial</option>
                                    <option <?php echo ($this->set_value('label_font-family')=="Calibri, Candara, Segoe, 'Segoe UI', Optima, Arial, sans-serif") ? 'selected="selected"' : ""  ?> value="Calibri, Candara, Segoe, \'Segoe UI\', Optima, Arial, sans-serif">Calibri</option>
                                    <option <?php echo ($this->set_value('label_font-family')=='Helvetica') ? 'selected="selected"' : ""  ?> value="Helvetica">Helvetica</option>
                                    <option <?php echo ($this->set_value('label_font-family')=='Tahoma') ? 'selected="selected"' : ""  ?> value="Tahoma">Tahoma</option>
                                    <option <?php echo ($this->set_value('label_font-family')=='Times New Roman') ? 'selected="selected"' : ""  ?> value="Times New Roman">Times New Roman</option>
                                </select><span class="f_help">Font Family</span>
                            </div>
                            <div class="floatleft width200"> <input value="<?php echo $this->set_value('label_font-size') ?>" type="text" name="label_font-size" class=" small"  /> Pixels<span class="f_help">Font Size</span></div>
                            <div class="floatleft width200"> <input value="<?php echo $this->set_value('label_font-color') ?>" type="text" name="label_font-color" class="clrpicker small"  /><span class="f_help">Font Color</span></div>
                        </div>
                        <div class="wpeer-clear"></div>
                    </div>
                    <div class="section last">
                        <div>
                            <input type="submit" class="uibutton loading" value="Save">
                            <a class="uibutton special preview"  >Preview</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="wpeer-clear" style="margin-top: 70px"></div>

<div class="wpeer-overlay" style="display: none"></div>
<div class="wpeer-exit-option-wrap" style="display:none;">
    <img src="<?php echo IMAGEPATH ?>close.png" alt="" class="wpeer-exitoption-close-button">
    <div class="wpeer-exitoption-title">
        <h1></h1>
    </div>
    <div class="wpeer-option-element-wrap">

    </div>

</div>
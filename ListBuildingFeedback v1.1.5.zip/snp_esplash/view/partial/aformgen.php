<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Zero
 * Date: 3/15/13
 * Time: 11:17 AM
 * To change this template use File | Settings | File Templates.
 */
?>
<?php include_once VIEWPATH.'/partial/navigation.php'; ?>
<div id="content" xmlns="http://www.w3.org/1999/html">
    <div class="inner">
        <div class="widget">
            <div class="header"><span><span class="ico gray window"></span>  FORM GENERATOR  </span></div>
            <div class="content">
                <form action="" method="post" id="aformgen">
                    <div class="boxtitle"><span class="ico gray link"></span>
                        PLEASE INPUT CORRESPONDING VALUE ON THE FIELD
                    </div>
                    <div class="section" >
                        <label> Form Post URL </label>
                        <div> <input value="<?php echo $this->set_value('meta_form_post_url') ?>" type="text" name="meta_form_post_url" class=" full"  /><span class="f_help">Enter post url of your autoresponder </span></div>
                        <label> Web Form Id </label>
                        <div> <input value="<?php echo $this->set_value('meta_web_form_id') ?>" type="text" name="meta_web_form_id" class=" full"  /><span class="f_help">Enter web form id (Aweber generates form id on their form generator)</span></div>
                        <label> List Name </label>
                        <div> <input value="<?php echo $this->set_value('listname') ?>" type="text" name="listname" class=" full"  /><span class="f_help">Enter the list name</span></div>
                        <label> Redirect Page </label>
                        <div> <input value="<?php echo $this->set_value('redirect') ?>" type="text" name="redirect" class=" full"  /><span class="f_help">Enter the link you want for redirection</span></div>
                        <label> Redirect On list </label>
                        <div> <input value="<?php echo $this->set_value('meta_redirect_onlist') ?>" type="text" name="meta_redirect_onlist" class=" full"  /><span class="f_help">Redirect on list. (Usually same as listname)</span></div>
                        <label> Adtracking </label>
                        <div> <input value="<?php echo $this->set_value('meta_adtracking') ?>" type="text" name="meta_adtracking" class=" full"  /><span class="f_help">Enter Ad Tracking Keyword</span></div>

                        <label> Use custom button image? </label>
                        <div> <input <?php echo ($this->set_value('use_image_for_button')) ? "checked='checked'" : ""?> type="checkbox" name="use_image_for_button" class=" full"  style="width: 15px" /><span class="f_help"></span></div>

                        <label> Image Url </label>
                        <div> <input value="<?php echo $this->set_value('button_image_url') ?>" type="text" name="button_image_url" class=" full"  /><span class="f_help">Custom Button Image</span></div>

                        <label> Requirement </label>
                        <div>
                            <select name="meta_required" data-placeholder="Choose a Req..." class="cust-select eotheader_font-family" tabindex="2">
                                <option <?php echo ($this->set_value('meta_required') == "email") ? 'selected="selected"' : "" ?> value="email">Email</option>
                                <option <?php echo ($this->set_value('meta_required') == "name,email") ? 'selected="selected"' : "" ?> value="name,email">Name and Email</option>
                            </select>
                        </div>
                    </div>
                    <div class="section last">
                        <div>
                            <input type="submit" class="uibutton loading" value="Generate Form">
                            <a class="uibutton special preview" onclick="document.getElementById('aformgen').reset()" >Clear</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
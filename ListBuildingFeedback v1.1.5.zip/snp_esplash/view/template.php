<!DOCTYPE html>
<html>
<head>
    <META HTTP-EQUIV="CACHE-CONTROL" CONTENT="NO-CACHE">
    <meta charset="utf-8" />
    <link href="<?php echo CSSPATH?>wpeer.theme.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo CSSPATH?>wpeer.style.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo CSSPATH?>wpeer.login.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo CSSPATH?>buttons.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo CSSPATH?>aweberform.classic.css" rel="stylesheet" type="text/css" />
    <?php echo $_styles ?>
    <title><?php echo $title ?></title>
    <script type="text/javascript">
        var baseurl = "<?php echo BASEURL;?>"
    </script>
</head>
<body>
<?php if(CoreLoader::get_flasher()):?>
    <div><?php echo CoreLoader::get_flasher() ?></div>
<?php endif;?>
<?php if(CoreLoader::get_flasher(true)):?>
    <div><?php echo CoreLoader::get_flasher(true) ?></div>
<?php endif;?>

<?php
print($content);
?>
<div class="wpeer-clear"></div>
<div id="wpeerversionBar" >
    <div class="wpeer-copyright" > &copy; Copyright 2012  All Rights Reserved <span class="tip"><a  href="http://ListBuildingFeedback.com" title="WebPeer" >Kevin Fahey</a> </span> </div>

</div>

<script type="text/javascript" src="<?php echo BASEURL ?>/resources/js/jquery-1.8.2.js"></script>
<?php echo $_scripts ?>
<script type="text/javascript" src="<?php echo BASEURL ?>/resources/js/wpeer.cp.script.js"></script>

</body>
</html>
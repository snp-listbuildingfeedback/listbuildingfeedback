<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Zero
 * Date: 3/15/13
 * Time: 9:03 AM
 * To change this template use File | Settings | File Templates.
 */
require_once(dirname(__FILE__)."../../../../../wp-load.php");

//DATABASE CONFIG
define('DATABASEHOST',DB_HOST);
define('DATABASEUSERNAME',DB_USER);
define('DATABASEPASSWORD',DB_PASSWORD);
define('DATABASENAME',DB_NAME);

define('USERTABLE','wpeersplashuser');
define('LEAVEOPTIONTABLE','wpeersplashloptions');
define('ESPLASHTABLE','wpeerexitsplash');


//CONFIG DECLARATION
define('LOGINTOKEN','LOGIN');
define('DASHBOARDTOKEN','DASHBOARD');

define('LOCATIONHOST',plugins_url());
define('BASEURL',plugins_url().'/snp_esplash');


// Path to Application folder
define('APPPATH', str_replace("\\", "/",realpath('')));
// Path to the View folder
define('VIEWPATH', str_replace("\\", "/", realpath('view')));
// Path to the Controller folder
define('CONTROLLERPATH', str_replace("\\", "/", realpath('controller')));
// Path to the Library folder
define('LIBPATH', str_replace("\\", "/", realpath('library')));
// Path to the Helper folder
define('HELPERPATH', str_replace("\\", "/", realpath('helper')));
// this global constant is deprecated.
define('EXT', '.php');


define('CSSPATH',BASEURL."/resources/css/");
define('JSPATH',BASEURL."/resources/js/");
define('IMAGEPATH',BASEURL."/resources/images/");
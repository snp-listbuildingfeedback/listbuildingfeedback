<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Zero
 * Date: 2/21/13
 * Time: 5:57 PM
 * To change this template use File | Settings | File Templates.
 */
session_start();
//set_error_handler("customError");

require_once LIBPATH.'/mysql.class.php';
require_once LIBPATH.'/classVigenere.php';
require_once LIBPATH.'/AntiXSS.php';
require_once LIBPATH.'/validation.class.php';

class CoreLoader extends MySQL
{
    protected $_formdata;
    protected $_isHttpPost = false;
    private static $_flash;
    protected $_data = array(
        'title'=>'',
        'content'=>'',
        '_styles'=>'',
        '_scripts'=>''
    );

    function __construct(){
        parent::__construct();
        $this->_isHttpPost = $_POST;
        $this->_formdata = $this->post();
    }

    public function get($tablename){
        $this->Query('Select * from '.$tablename);
        if ($this->RowCount() > 0) {
            $data = array();
            while($row = $this->Row()){
                $data[] = $row;
            }
            return $data;
        } else {
            return false;
        }
    }

    public function getquery($query){
        $this->Query($query);
        if ($this->RowCount() > 0) {
            $data = array();
            while($row = $this->Row()){
                $data[] = $row;
            }
            return $data;
        } else {
            return false;
        }
    }

    public function redirect($controller, $method='index'){
        header('Location: '.BASEURL."/cp.php?c=$controller&m=$method");
    }

    public function set_session($key, $value){
        $_SESSION[$key] = $value;
    }

    public function get_session($key){
        return (isset($_SESSION[$key]))?$_SESSION[$key]:false;
    }

    public function kill_session($key,$all=false){
        if($all){
            session_destroy();
        }else{
            session_unset($_SESSION[$key]);
        }

    }

    public function method_call($controller,$method){
        call_user_func(array($controller,$method));
    }

    public function view($view, $vars = array()){
       return $this->_load(array('_view' => $view, '_vars' => self::_ci_object_to_array($vars)));
    }

    protected function _ci_object_to_array($object)
    {
        return (is_object($object)) ? get_object_vars($object) : $object;
    }


    public function post()
    {
        if($_POST){
            $data = array();
            foreach($_POST as $key=>$value){
                /*$data[$key] = AntiXSS::setEncoding($value, "UTF-8"); ;*/
                $data[$key] = htmlentities($value, ENT_QUOTES, "UTF-8");
            }
            $this->_formdata = $data;
            return $data;
        }
        return false;
    }

    public function set_value($key){
        if(isset($this->_formdata[$key])){
            return  html_entity_decode($this->_formdata[$key],ENT_QUOTES,"UTF-8");
        }
        return "";
    }

    public static function set_flasher($msg = '',$session = false){
        ($session) ? $_SESSION['_flash']=$msg : self::$_flash = $msg;
    }

    public static function get_flasher($session = false){
        if(!$session)
            return (self::$_flash) ? self::$_flash : false;
        else{
            if(isset($_SESSION['_flash'])){
                $flash = $_SESSION['_flash'];
                $_SESSION['_flash']="";
                return $flash;
            }else
                return false;
        }
    }

    public static function string_generator($length = 8)
    {
        $random = "";
        srand((double)microtime()*1000000);
        $char_list = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $char_list .= "abcdefghijklmnopqrstuvwxyz";
        $char_list .= "1234567890";
        // Add the special characters to $char_list if needed

        for($i = 0; $i < $length; $i++)
        {
            $random .= substr($char_list,(rand()%(strlen($char_list))), 1);
        }
        return $random;
    }

    protected function _load($_data)
    {
        $cached = array();
        if (is_array($_data['_vars']))
        {
            $cached = array_merge($cached, $_data['_vars']);
        }
        extract($cached);

        ob_start();
        if ((bool) @ini_get('short_open_tag') === FALSE)
        {
            echo eval('?>'.preg_replace("/;*\s*\?>/", "; ?>", str_replace('<?=', '<?php echo ', file_get_contents(VIEWPATH.'/'.$_data['_view'].EXT))));
        }
        else
        {
            include_once(VIEWPATH.'/'.$_data['_view'].EXT); // include() vs include_once() allows for multiple views with the same name
        }

        $buffer = ob_get_contents();
        @ob_end_clean();
        return $buffer;
    }

}

class ProcessEnum{
    const Insert = 0;
    const Update = 1;
}

class ElementStyleEnum{
    const Box = 0;
    const Header = 1;
    const Option = 2;
}

class ElementStyleTypeEnum{
    const Font = 0;
    const FontSize = 1;
    const widthSize = 2;
    const heightSize = 3;
    const FontColor = 4;
    const marginSize = 5;
    const borderSize = 6;
}

function customError($errno, $errstr)
{
    echo "<b>Error:</b> [$errno] $errstr<br>";
    echo "Ending Script";
    die();
}





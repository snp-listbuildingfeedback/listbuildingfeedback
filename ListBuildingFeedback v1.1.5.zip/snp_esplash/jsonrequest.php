<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Zero
 * Date: 3/15/13
 * Time: 10:30 AM
 * To change this template use File | Settings | File Templates.
 */
include_once dirname(__FILE__)."/core/config.php";
include_once dirname(__FILE__)."/library/classVigenere.php";
include_once dirname(__FILE__)."/library/mysql.class.php";

$enc = new classVigenere();
echo json_encode($enc->decrypt('DEFAULTURL'));
if($_POST){
    $option_value = $_POST['optionValue'];
    $custom_value = (isset($_POST['customreason'])) ? $_POST['customreason'] : "";
    $ip = $_SERVER['REMOTE_ADDR'];
    $linkurl = $_POST['linkurl'];

    $data = array(
        'id'=>'default',
        'exiturl'=>"'".$linkurl."'",
        'description'=>"'".$option_value."'",
        'customdescription'=>"'".$custom_value."'",
        'ip'=>"'".$ip."'",
        'createdat'=>"'".date('Y-m-d H:i:s')."'"
    );

    $db = new MySQL();
    $insert =  $db->InsertRow(LEAVEOPTIONTABLE,$data);

    echo json_encode($insert);
}
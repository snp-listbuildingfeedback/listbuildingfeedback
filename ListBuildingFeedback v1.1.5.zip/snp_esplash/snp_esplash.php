<?php
/*
Plugin Name: List Building Feedback Plugin
Plugin URI: http://ListBuildingFeedback.com
Description: Customizable Exit Splash
Version: 1.1.5
Author: Kevin Fahey
Author URI: http://kevinfahey.net/
*/

define('SNPPLUGIN_URL', plugin_dir_url( __FILE__ ));
include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
include_once "core/config.php";
class Snp_Esplash{

    public function  __construct(){
        $this->add_menu_page();
        $this->add_shortcode_tags();
        $this->add_scripts();
    }

    public function add_menu_page(){
        add_action('admin_menu',array($this,'a_options_page'));
    }

    public function add_scripts(){
        global $wpdb;
        $query  = "SELECT * FROM ".ESPLASHTABLE." where exiturl = 'DEFAULTURL'";
        $results = $wpdb->get_row($query);
        if($results){
            add_action('wp_enqueue_scripts', array($this,'wp_load_js_and_css') );
        }
    }

    public function wp_load_js_and_css(){
        //wp_enqueue_script('wpeersplasher.php',SNPPLUGIN_URL . 'wpeersplasher.php?exit=NUWfSSCCLf', array('jquery'), '1.0.2');
        wp_enqueue_script('snp.init.script.js',SNPPLUGIN_URL . 'resources/js/snp.init.script.js', array('jquery'), '1.0.2');

    }

    public function a_options_page(){
        add_options_page('List Building Feedback','List Building Feedback','administrator',__FILE__,array($this,'display_options_page'));
    }

    public function add_shortcode_tags(){
        add_shortcode('snp_esplash_tag',array($this,'display_shorttags'));
    }

    public function display_shorttags($attr){
        If (is_plugin_active('snp_esplash/snp_esplash.php')) {
            //plugin is activated
            $link = "<!--/**************************************************************************************/-->";
            $link .= "<script src='".plugins_url().'/snp_esplash'."/resources/js/jquery-1.8.2.js'></script>";
            $link .= "<script src='".plugins_url().'/snp_esplash'."/wpeersplasher.php?exit=".$attr['ecode']."'></script>";
            $link .= "<!--/*************************************************************************************/-->";

            return $link;
        }
    }

    public function display_options_page(){
    ?>
        <script type="text/javascript">
            <!--
            var snp = {};
            snp.query = jQuery.noConflict(true);
            function autoResize(){
                snp.query('#themeframe').height(snp.query('#themeframe').contents().height());
            }
            snp.query(document).ready(function() {
                snp.query(window).bind('resize', autoResize);
                snp.query("html,body").scrollTop();
            });
            //-->
        </script>
        <div class="wrap">
            <?php screen_icon(); ?>
            <h2>List Building Feedback Settings</h2>
            <div id="framewrap" style="width:100%; height: 100%; margin-top: 20px">
                <iframe  id="themeframe" on onLoad="autoResize();" src="<?php echo plugins_url()?>/snp_esplash/cp.php?c=Dashboard&m=index&ran=<?php echo wp_generate_password() ?>" style="width: 100%; border: none; overflow-y: hidden  " frameBorder="0"></iframe>
            </div>
        </div>
    <?php
    }
}

new Snp_Esplash();
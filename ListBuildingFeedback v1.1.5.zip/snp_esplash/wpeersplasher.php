<?php
Header("Content-Type: application/x-javascript; charset=UTF-8");
include dirname(__FILE__).'/core/config.php';
include_once dirname(__FILE__)."/library/mysql.class.php";
include_once dirname(__FILE__)."/library/classVigenere.php";
include_once dirname(__FILE__)."/helper/url.php";

$enc = new classVigenere();
$idarr = explode('is', $enc->decrypt($_GET['exit']));
$exit = $enc->decrypt($_GET['exit']);
$db = new MySQL();
$row = $db->QuerySingleRow("Select * from ".ESPLASHTABLE." where id='". $idarr[1] ."'");
$lbl_array = array(
    $row->optionlabela,$row->optionlabelb,$row->optionlabelc,$row->optionlabeld
);

$aweberoptions = json_encode(array(
    str_replace(array("\r\n", "\n", "\r"), ' ', html_entity_decode($row->awebera)),
    str_replace(array("\r\n", "\n", "\r"), ' ', html_entity_decode($row->aweberb)),
    str_replace(array("\r\n", "\n", "\r"), ' ', html_entity_decode($row->aweberc)),
    str_replace(array("\r\n", "\n", "\r"), ' ', html_entity_decode($row->aweberd)),
    str_replace(array("\r\n", "\n", "\r"), ' ', html_entity_decode($row->awebercustom))
));
$lbl_array_el = array();
foreach ($lbl_array as $ar) {
    $lbl = explode('|',$ar);
    if(count($lbl)>1){
        if(trim($lbl[0]) != ""){
            array_push($lbl_array_el,array('label'=>$lbl[0],'value'=>(trim($lbl[1]) == "") ? $lbl[0] : $lbl[1] ));
        }

    }
}

$js_array = json_encode($lbl_array_el);

?>

<!--<script>-->
/**
* Created with JetBrains PhpStorm.
* User: Zero
* Date: 2/21/13
* Time: 6:10 PM
* To change this template use File | Settings | File Templates.
*/
var eurl = '<?php echo html_entity_decode($row->exiturl) ?>';
var wpeer = {};
wpeer.query = jQuery.noConflict(true);
wpeer.query.extend({postJSON:function(url,data,callback){return wpeer.query.post(url,data,callback,"json")}});
wpeer.query.extend({cElement:function(e){
    if(wpeer.query('#'+ e.elId).length == 0){
        switch (e.elName){
            case "div":
                wpeer.query('<'+e.elName+'/>', {
                    id:e.elId
                }).css(e.eStyle).appendTo(e.eAppendTo);
                break;
            case "img":
                wpeer.query('<'+e.elName+'/>', {
                    id:e.elId,
                    alt:e.eAlt,
                    src:e.eSrc
                }).css(e.eStyle).appendTo(e.eAppendTo);
                break;
        }
    }
}});

wpeer.query.extend({addElementEvent:function(e,event,callback){
    wpeer.query(e).live(event,callback);
}});
wpeer.query(function() {
    wpeer.query.fn.reverse = [].reverse;
    var locationhost = '<?php echo BASEURL ?>';
    var url='http://'+window.location.hostname;
    var imgsource = '<?php echo IMAGEPATH ?>';
    var mEngine = {
        wrapHeight:0,
        elprefix:'wpeer',
        isExitSplash:true,
        isExitSplashOption:true,
        hasChanged:false,
        optvalue:"",
        custreason:"",
        siteuri:locationhost+'/',
        appLibrary:{
            ISBUTTONIMAGE:"<?php echo html_entity_decode($row->isfeedbackbuttonimage) ?>",
            BUTTONIMAGEURL:"<?php echo html_entity_decode($row->feedbackbuttonimageurl) ?>",
            ISCUSTOMREASON:"<?php echo html_entity_decode($row->allowcustomreason) ?>",
            EXITMESSAGE:"<?php echo html_entity_decode($row->alerttext) ?>",
            OPTIONTITLE : "<?php echo html_entity_decode($row->eottitle) ?>",
            POWEREDBY : "<?php echo html_entity_decode($row->poweredby) ?>",
            POWEREDBYLINK : "<?php echo html_entity_decode($row->poweredbylink) ?>",
			POWEREDBYCOLOR : "<?php echo html_entity_decode($row->poweredbycolor) ?>",
            LABELS:<?php echo $js_array ?>,
            EXITSPLASHLINK:"<?php echo html_entity_decode($row->exitsplashpage) ?>",
            AWEBER: '<?php echo str_replace(array("\r\n", "\n", "\r"), ' ', html_entity_decode($row->emailvaluelabel) ); ?>',
            AWEBEROPTION: <?php echo $aweberoptions ?>,
            EOTMAINDIVSTYLE:"<?php echo html_entity_decode($row->eotmaindivstyles) ?>",
            EOTTITLEDIVSTYLE:"<?php echo html_entity_decode($row->eotheaderstyles) ?>",
            EOTHEADERSTYLE:"<?php echo html_entity_decode($row->eotheaderstyles) ?>",
            EOTOPTIONLABELSTYLE:"<?php echo html_entity_decode($row->optionlabelstyle) ?>",
            FEEDBACKBUTTON:"<?php echo html_entity_decode($row->feedbackbutton) ?>",
            EOTTHEME:""
        },

        server:function(){
            var siteurl=mEngine.siteuri;
            this.sendtoServer=function(data, controller,callback){
                try{
                    wpeer.query.postJSON(siteurl+controller,data,callback);
                }catch(err){
                    alert(err);
                }
            }
        },
        wpcookies:function(){
            if(typeof mEngine.wpcookies._initialized == "undefined") {
                mEngine.wpcookies.prototype.getCookie = function(c_name){
                    var i,x,y,ARRcookies=document.cookie.split(";");
                    for (i=0;i<ARRcookies.length;i++)
                    {
                        x=ARRcookies[i].substr(0,ARRcookies[i].indexOf("="));
                        y=ARRcookies[i].substr(ARRcookies[i].indexOf("=")+1);
                        x=x.replace(/^\s+|\s+$/g,"");
                        if (x==c_name)
                        {
                            return unescape(y);
                        }
                    }
                };

                mEngine.wpcookies.prototype.setCookie = function(c_name,value,exdays){
                    var exdate=new Date();
                    exdate.setDate(exdate.getDate() + exdays);
                    var c_value=escape(value) + ((exdays==null) ? "" : "; expires="+exdate.toUTCString());
                    document.cookie=c_name + "=" + c_value;
                };

                mEngine.wpcookies.prototype.checkCookie = function(c_name){
                    var self = this;
                    var ck=self.getCookie(c_name);

                    if (ck!=null && ck!="")
                    {
                       return true;
                    }else{
                        return false;
                    }
                };

                mEngine.wpcookies.prototype.init = function(){};
                mEngine.wpcookies._initialized = true;
            }
            this.init();
        },
        ui:{
            dom:function(){
                this.domevent = new mEngine.ui.domEvent();
                if(typeof mEngine.ui.dom._initialized == "undefined") {
                    mEngine.ui.dom.prototype.overlay=function(){
                        //Create Overlay
                        if(!mEngine.isExitSplashOption)return;
                        if(wpeer.query('#'+mEngine.elprefix+'overlay').length == 0){
                            wpeer.query('<div/>', {
                                id: mEngine.elprefix+'overlay'
                            }).addClass(mEngine.elprefix+'-overlay').appendTo('body');
                        }
                    };

                    mEngine.ui.dom.prototype.exitoption=function(){
                        var self = this;
                        if(!mEngine.isExitSplashOption)return;
                        if(wpeer.query('#'+mEngine.elprefix+'-exit-option-wrap').length == 0){
                            mEngine.isExitSplashOption=false;

                            $exitDiv = wpeer.query('<div/>', {
                                id: mEngine.elprefix+'-exit-option-wrap'
                            }).addClass(mEngine.elprefix+'-exit-option-wrap').appendTo('body').attr('style',mEngine.appLibrary.EOTMAINDIVSTYLE);

                            $exitDiv.append('<img src="'+ imgsource +'close.png" alt="" class="'+ mEngine.elprefix +'-exitoption-close-button">');

                            $exitDiv.append('<div class="'+ mEngine.elprefix +'-exitoption-title" style="'+mEngine.appLibrary.EOTTITLEDIVSTYLE +'">' +
                                '<h1 >'+mEngine.appLibrary.OPTIONTITLE+'</h1>' +
                                '</div>' +
                                '<div class="'+mEngine.elprefix+'-option-element-wrap '+ mEngine.appLibrary.EOTTHEME +'"></div>');

                            wpeer.query.each(mEngine.appLibrary.LABELS,function(index, item){
                                wpeer.query('.'+mEngine.elprefix+'-option-element-wrap').append(
                                    '<p><input type="radio" ind="'+index+'" value="'+ wpeer.query.trim(item.value)+'" name="radioptions" id="'+mEngine.elprefix+'radioptions'+index+'"><label style="'+mEngine.appLibrary.EOTOPTIONLABELSTYLE+'" for="'+mEngine.elprefix+'radioptions'+index+'">'+item.label+'</label></p>'
                                );
                            });
                            /*this if for custom reason*/
                            if(mEngine.appLibrary.ISCUSTOMREASON){
                                wpeer.query('.'+mEngine.elprefix+'-option-element-wrap').append(
                                        '<p><input type="radio" class="customreasonRadio" id="customreasonRadio" name="radioptions" /><label style="'+mEngine.appLibrary.EOTOPTIONLABELSTYLE+'" for="customreasonRadio">Other reason:</label></p>'
                                );
                            }
                            var butt = (mEngine.appLibrary.ISBUTTONIMAGE) ? '<a class="'+mEngine.elprefix+'-trace-button wpeer-ui-button-image-flash" href="#"><img src="'+ mEngine.appLibrary.BUTTONIMAGEURL +'" alt=""></a>'  : '<a class="'+mEngine.elprefix+'-trace-button" href="#">'+mEngine.appLibrary.FEEDBACKBUTTON+'</a>';
                            if(wpeer.query.trim(mEngine.appLibrary.FEEDBACKBUTTON)!=""){
                                if(wpeer.query.trim(mEngine.appLibrary.AWEBER)==""){
                                    wpeer.query('.'+mEngine.elprefix+'-option-element-wrap').append(
                                            butt
                                    );
                                }
                            }

                            wpeer.query('.'+mEngine.elprefix+'-option-element-wrap').append(
                                mEngine.appLibrary.AWEBER
                            );

                            if(wpeer.query.trim(mEngine.appLibrary.POWEREDBY)){
                                wpeer.query('.'+mEngine.elprefix+'-exit-option-wrap').append(
                                    '<div class="'+mEngine.elprefix+'-poweredby">'+
                                    '<a class="'+mEngine.elprefix+'-cookie-button" href="">Do not show this message again</a>' +
                                    '<a target="_blank" href="'+mEngine.appLibrary.POWEREDBYLINK+'" style="color:#'+ mEngine.appLibrary.POWEREDBYCOLOR +'">Powered by: '+mEngine.appLibrary.POWEREDBY+'</a></div>'
                                );
                            }


                            mEngine.wrapHeight = $exitDiv.height();
                            self.domevent.esplashEvent();
                        }

                    }

                    mEngine.ui.dom.prototype.init = function(){};
                    mEngine.ui.dom._initialized = true;
                }
                this.init();
            },
            domEvent:function(){
                this._cookies = new mEngine.wpcookies();
                if(typeof mEngine.ui.domEvent._initialized == "undefined") {
                    mEngine.ui.domEvent.prototype.closeelementEvent = function(){
                        wpeer.query('.'+mEngine.elprefix+'-exitoption-close-button, #'+mEngine.elprefix+'overlay').live('click',function(){
                            wpeer.query('.'+mEngine.elprefix+'-exitoption-close-button, #'+mEngine.elprefix+'overlay, #'+mEngine.elprefix+'-exit-option-wrap').remove();
                            var data={};

                            /*CAPTURE CUSTOM REASON*/
                            if(mEngine.appLibrary.ISCUSTOMREASON && mEngine.custreason != ""){
                                mEngine.hasChanged = true;
                            }

                            if(mEngine.hasChanged){
                                data.customreason = mEngine.custreason;
                                data.optionValue = mEngine.optvalue;
                                data.linkurl = (eurl == 'DEFAULTURL') ? document.URL : eurl;
                                var srv = new mEngine.server();
                                srv.sendtoServer(data,'jsonrequest.php',function(){});
                            }
                        });
                    };

                    mEngine.ui.domEvent.prototype.esplashEvent = function(){
                        var self = this;
                        self.cookieRestriction();
                        self.buttonAwebEvent();
                        self.optCheckEvent();
                    };

                    mEngine.ui.domEvent.prototype.optCheckEvent = function(){
                        var self= this;

                        wpeer.query('.'+mEngine.elprefix+'-exit-option-wrap').css({"height":"auto"});
                        wpeer.query('input[name="radioptions"]').live('change',function(){
                            mEngine.hasChanged = true;
                            mEngine.optvalue = wpeer.query(this).val();
                            if(mEngine.appLibrary.AWEBEROPTION[wpeer.query(this).attr('ind')] != "" && mEngine.appLibrary.AWEBEROPTION[wpeer.query(this).attr('ind')] != null){
                                wpeer.query('.'+mEngine.elprefix+'-trace-button').hide();
                                wpeer.query('.wpeer-aweber-form-gene').remove();
                                var ml = mEngine.appLibrary.AWEBEROPTION[wpeer.query(this).attr('ind')];
                                wpeer.query('.'+mEngine.elprefix+'-option-element-wrap').append(
                                        '<div class="'+ mEngine.elprefix +'-aweber-form-gene">'+ml+'</div>'
                                );
                                
                            }else{
                                if(wpeer.query(this).attr('class')=='customreasonRadio'){
                                    wpeer.query('.'+mEngine.elprefix+'-trace-button').hide();
                                    wpeer.query('.wpeer-aweber-form-gene').remove();
                                    if(wpeer.query('.'+mEngine.elprefix+'-trace-button').length){
                                        wpeer.query('.'+mEngine.elprefix+'-trace-button').before(
                                                '<div class="'+ mEngine.elprefix +'-aweber-form-gene">'
                                                        + '<p style="margin-bottom: 20px"><label style="padding: 10px 0; float:left;margin-right: 10px;display: block;'+ mEngine.appLibrary.EOTOPTIONLABELSTYLE +'" for="'+mEngine.elprefix+'customreason">Enter your Reason: </label><input style="width:95%" type="text" name="'+mEngine.elprefix+ 'customreason"  id="'+mEngine.elprefix+ 'customreason" /></p>'
                                                        + mEngine.appLibrary.AWEBEROPTION[4] +
                                                        '</div>'
                                        );
                                        /*if(!wpeer.query('#'+mEngine.elprefix+'-button-aweber').length){
                                            wpeer.query('.'+mEngine.elprefix+'-trace-button').show();
                                        }else{
                                            wpeer.query('#'+mEngine.elprefix+'-button-aweber').text(wpeer.query('.'+mEngine.elprefix+'-trace-button').text());
                                        }*/
                                    }
                                }
                                
                            }
                        });
                        wpeer.query('input[name="'+mEngine.elprefix+ 'customreason"]').live('change',function(){
                            mEngine.custreason = wpeer.query(this).val();
                        });
                    };

                    mEngine.ui.domEvent.prototype.cookieRestriction = function(){
                        var self = this;
                        wpeer.query('.'+mEngine.elprefix+'-cookie-button').live('click',function(e){
                            self._cookies.setCookie(mEngine.elprefix+'-ckie',true,7);
                            wpeer.query('.'+mEngine.elprefix+'-exitoption-close-button').trigger('click');
                            mEngine.isExitSplash=false;
                            mEngine.isExitSplashOption=false;
                            e.preventDefault();
                        });

                        wpeer.query('.'+mEngine.elprefix+'-trace-button').live('click',function(e){
                            wpeer.query('.'+mEngine.elprefix+'-exitoption-close-button').trigger('click');
                            e.preventDefault();
                        });


                    };

                    mEngine.ui.domEvent.prototype.buttonAwebEvent = function(){
                        var self = this;
                        wpeer.query('#wpeer-button-aweber').live('click',function(){
                            var $nameEl = wpeer.query('input[name="name"]');
                            var $emailEl = wpeer.query('#wpeer-aweber-email');
                            $nameEl.removeClass(mEngine.elprefix+'-error');
                            $emailEl.removeClass(mEngine.elprefix+'-error');
                            if(wpeer.query.trim($emailEl.val()) == ''){
                                $emailEl.addClass(mEngine.elprefix+'-error');
                            }else if(!self.isEmail(wpeer.query.trim($emailEl.val()))){
                                $emailEl.addClass(mEngine.elprefix+'-error');
                            }else{
                                mEngine.isExitSplash = false;
                                if(mEngine.hasChanged){
                                    var data ={};
                                    data.customreason = mEngine.custreason;
                                    data.optionValue = mEngine.optvalue;
                                    data.linkurl = (eurl == 'DEFAULTURL') ? document.URL : eurl;
                                    var srv = new mEngine.server();
                                    srv.sendtoServer(data,'jsonrequest.php',function(){});
                                }
                                wpeer.query('#wpeer-aweber-form-api').submit();
                            }
                        });
                    };

                    mEngine.ui.domEvent.prototype.isEmail = function(e){
                        var filter = /^\s*[\w\-\+_]+(\.[\w\-\+_]+)*\@[\w\-\+_]+\.[\w\-\+_]+(\.[\w\-\+_]+)*\s*$/;
                        return String(e).search (filter) != -1;
                    };
                    mEngine.ui.domEvent.prototype.inputEvent = function(){
                        wpeer.query('input[name="email"]').live('change',function(){
                            if(wpeer.query(this).attr('id') != mEngine.elprefix+"-aweber-email"){
                                if(wpeer.query.trim(wpeer.query(this).val()) != ""){
                                    mEngine.isExitSplash = false;
                                }
                            }
                        });
                    };
                    mEngine.ui.domEvent.prototype.init = function(){
                        var self = this;
                        self.inputEvent();
                    };
                    mEngine.ui.domEvent._initialized = true;
                }
                this.init();
            }
        },
        proc:{
            wsplasher:function(){
                this.dom = new mEngine.ui.dom();
                this.domevent = new mEngine.ui.domEvent();
                this._cookies = new mEngine.wpcookies();
                if(typeof mEngine.proc.wsplasher._initialized == "undefined") {

                    mEngine.proc.wsplasher.prototype.TryToleaveEvent=function(){
                        var self = this;
                        wpeer.query(document).bind('mouseleave',function(){
                            if(mEngine.isExitSplashOption){
                                if(!self._cookies.checkCookie(mEngine.elprefix+'-ckie')){
                                self.dom.overlay();
                                self.dom.exitoption();
                                self.domevent.closeelementEvent();
                                }
                            }
                        });
                    };

                    mEngine.proc.wsplasher.prototype.winunloader = function(){
                        var self = this;
                        wpeer.query(window).bind('beforeunload', function(){
                            if(mEngine.isExitSplash){
                                if(!self._cookies.checkCookie(mEngine.elprefix+'-ckie')){
                                wpeer.query('.'+mEngine.elprefix+'-exitoption-close-button').trigger('click');
                                self.exitSplashMethod();
                                return mEngine.appLibrary.EXITMESSAGE;
                                }
                            }
                        });
                    };

                    mEngine.proc.wsplasher.prototype.exitSplashMethod = function(){
                        var self = this;
                        mEngine.isExitSplash = false;
                        window.scrollTo(0,0);
                        var isChrome = navigator.userAgent.toLowerCase().indexOf('chrome') > -1;
                        wpeer.query('#wpeerSplashOverlay, .wpeer-exitoption-close-button, .exitoption').remove();
                        self.createExitSPlasher();
                        if(mEngine.appLibrary.EXITMESSAGE != ""){
                            window.alert(mEngine.appLibrary.EXITMESSAGE);
                        }

                    };

                    mEngine.proc.wsplasher.prototype.allanchorevent=function(){
                        wpeer.query('a').live('click',function(){
                            mEngine.isExitSplash = false;
                        });
                    };

                    mEngine.proc.wsplasher.prototype.overlayCreator=function(){
                        //Create Overlay
                        if(wpeer.query('#wpeerSplashOverlay').length == 0){
                            wpeer.query('<div/>', {
                                id: 'wpeerSplashOverlay'
                            }).css(mEngine.appLibrary.OVERLAYSTYLE).appendTo('body');
                        }
                    };

                    mEngine.proc.wsplasher.prototype.createExitSPlasher=function(){
                        mEngine.isExitSplashOption = false;
                        var exitsplashpage = mEngine.appLibrary.EXITSPLASHLINK;
                        var theDiv = '<div id="ExitSplashDiv"  style=" display:block; width:100%; height:100%; position:absolute; background:#FFFFFF; margin-top:0px; margin-left:0px;z-index:10" align="center">';
                        theDiv = theDiv + '<div id="ExitCancelButtonImageDiv" style="z-index:11; background: #ffffff; width: 100%;" align="left"><img style="display: block; z-index: 99999" src="'+imgsource+'close.jpg?time=<?php echo date('His') ?>" border="0" /></div>';
                        theDiv = theDiv + '<iframe class="exitsplashiframe" style="z-index: 12; overflow:hidden; width: 100%; height: 100%" src="'+exitsplashpage+'" width="100%" height="100%" align="middle" frameborder="0"></iframe>';
                        theDiv = theDiv + '</div>';

                        wpeer.query.cElement({"elName":"div",
                            "elId":"wpeerSplashDivs",
                            "eStyle":{
                                "width":"100%",
                                "height":"100%",
                                "position":"absolute",
                                "top":"0px",
                                "left":"0px",
                                "backgroundColor":"#fff"
                            },
                            "eAppendTo":"body"
                        });
                        wpeer.query('#wpeerSplashDivs').append(theDiv).live('mouseover',function(){
                            wpeer.query('#ExitCancelButtonImageDiv').remove();
                            wpeer.query('#ExitSplashDiv iframe').css({'position':'fixed','top':'30px','left':'0','overflow-y':'auto'});
                            wpeer.query('body').css('overflow','hidden');
                            wpeer.query('.powerdbyholder').css({position:'absolute','top':'0','left':'0',display:'block',width:'100%','z-index':'200'});
                            wpeer.query('.powerdbyholder').find('img').show().css({'z-index':'999999','height':'20px','width':'20px','display':'block'});
                        });

                        if(wpeer.query.trim(mEngine.appLibrary.POWEREDBY)){
                            wpeer.query('#ExitCancelButtonImageDiv').after(
                                '<div class="powerdbyholder"><a class="powerdbylink" target="_blank" href="'+mEngine.appLibrary.POWEREDBY+'">Powered by: '+mEngine.appLibrary.POWEREDBY+'</a><img src="'+ imgsource +'close.png" alt="Close" border="0" /></div>'
                            );
                        }

                        wpeer.query('.powerdbyholder').find('img').live('click',function(){
                            wpeer.query('.exitsplashiframe').css({'top':'0'});
                            wpeer.query('.powerdbyholder').remove();
                            wpeer.query('#wpeerSplashDivs').die('mouseover');
                        });

                    };


                    mEngine.proc.wsplasher.prototype.initialize = function(){
                        var self = this;
                        self.winunloader();
                        self.allanchorevent();
                        self.TryToleaveEvent();
                        /*FOR WORDPRESS*/
                        wpeer.query("#branding").css('z-index','1');
                        if (document.createStyleSheet){
                            document.createStyleSheet(locationhost + '/esplash/resources/css/aweberform.classic.css');
                        }
                        else {
                            wpeer.query("head").append(wpeer.query("<link rel='stylesheet' href='"+locationhost+"/resources/css/aweberform.classic.css' type='text/css' media='screen' />"));
                        }
                    };
                    mEngine.proc.wsplasher._initialized = true;
                }
                this.initialize();

            }
        }
    }
    mEngine.isExitSplash=true;
    if(document.URL == eurl){
        if (typeof (Exitsplasher) != 'undefined' && Exitsplasher === null){
            Exitsplasher = new mEngine.proc.wsplasher();
        }

    }else if(document.URL.replace('http://www.','http://') == eurl){
        if (typeof (Exitsplasher)!= 'undefined' && Exitsplasher === null){
            Exitsplasher = new mEngine.proc.wsplasher();
        }
    }

    wpeer.query('#af-submit-image-').live('click',function(){
        mEngine.isExitSplash = false;
        if(mEngine.hasChanged){
            var data ={};
            data.customreason = mEngine.custreason;
            data.optionValue = mEngine.optvalue;
            data.linkurl = (eurl == 'DEFAULTURL') ? document.URL : eurl;
            var srv = new mEngine.server();
            srv.sendtoServer(data,'jsonrequest.php',function(){});
        }
    });

    <?php
     if(trim(html_entity_decode($row->exiturl))=="DEFAULTURL"){?>
        if (typeof (Exitsplasher) != 'undefined' && Exitsplasher === null){
            Exitsplasher = new mEngine.proc.wsplasher();
         }
     <?php }?>
});


<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Zero
 * Date: 5/8/13
 * Time: 9:02 PM
 * To change this template use File | Settings | File Templates.
 */

//if uninstall not called from WordPress exit

include dirname(__FILE__).'/core/config.php';
if ( !defined( 'WP_UNINSTALL_PLUGIN' ) )
    exit ();

global $wpdb;
$wpdb->query("DROP table ".USERTABLE);
$wpdb->query("DROP table ".LEAVEOPTIONTABLE);
$wpdb->query("DROP table ".ESPLASHTABLE);

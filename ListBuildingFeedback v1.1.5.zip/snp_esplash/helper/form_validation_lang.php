<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Zero
 * Date: 3/4/13
 * Time: 8:21 PM
 * To change this template use File | Settings | File Templates.
 */

$lang['hasValue']			= "The %s field is required.";
$lang['isInternetURL']			= "The %s field must be a valid url.";
$lang['isNumber']			= "The %s field must be a number.";

<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Zero
 * Date: 3/4/13
 * Time: 8:21 PM
 * To change this template use File | Settings | File Templates.
 */

$config = array(
    'splashsettings' => array(
        array(
            'field' => 'exiturl',
            'label' => 'Link',
            'rules' => 'hasValue|isInternetURL'
        ),
        /*array(
            'field' => 'feedbackbuttonimageurl',
            'label' => 'Button image url',
            'rules' => 'hasValue|isInternetURL'
        ),*/
        array(
            'field' => 'eottitle',
            'label' => 'Header Title',
            'rules' => 'hasValue'
        ),
        /*array(
            'field' => 'eotbox_width',
            'label' => 'Box width',
            'rules' => 'isNumber'
        ),
        array(
            'field' => 'eotbox_height',
            'label' => 'Box height',
            'rules' => 'isNumber'
        ),
        array(
            'field' => 'eotbox_margin-top',
            'label' => 'Box top margin',
            'rules' => 'isNumber'
        ),
        array(
            'field' => 'eotbox_border',
            'label' => 'Box border thickness',
            'rules' => 'isNumber'
        ),*/
    )
);